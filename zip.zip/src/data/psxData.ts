import { Company } from '../types';

export const psxCompanies: Company[] = [
  {
    symbol: 'MEBL',
    name: 'Meezan Bank Limited',
    logo: '🕋',
    ceo: 'Irfan Siddiqui',
    sector: 'Islamic Commercial Banking',
    products: ['Shariah-Compliant Retail Banking', 'Corporate Finance', 'Car Ijarah', 'Easy Home Loans', 'Islamic Mutual Funds'],
    history: 'Established in 1997 as an investment bank, Meezan Bank was awarded Pakistan\'s first commercial Islamic banking license in 2002. It currently stands as the fastest-growing and one of the largest banks in Pakistan, fully adhering strictly to Islamic Shariah-principles.',
    price: 185.50,
    change: 4.25,
    changePercent: 2.34,
    peRatio: 4.8,
    pbRatio: 1.85,
    roe: 42.1,
    eps: 38.65,
    dividendHistory: [
      { year: 2025, yield: 12.5, payout: 'Rs 12.00 per share' },
      { year: 2024, yield: 11.2, payout: 'Rs 10.50 per share' },
      { year: 2023, yield: 9.8, payout: 'Rs 8.00 per share' }
    ],
    riskScore: 25,
    competitors: ['HBL', 'BAFL', 'MCB'],
    news: [
      { title: 'Meezan Bank records robust quarterly earnings jump of 20%', source: 'Business Recorder', time: '2 hours ago', sentiment: 'positive' },
      { title: 'Paving the way for Islamic Fintech solutions across Pakistan', source: 'Profit Magazine', time: '1 day ago', sentiment: 'positive' },
      { title: 'SBP commends Meezan Bank on digital onboarding dominance', source: 'The News', time: '3 days ago', sentiment: 'positive' }
    ],
    website: 'https://www.meezanbank.com'
  },
  {
    symbol: 'ENGRO',
    name: 'Engro Corporation',
    logo: '⚡',
    ceo: 'Ghias Khan',
    sector: 'Conglomerates & Fertilizers',
    products: ['Urea and DAP Fertilizers', 'Vopak Liquid Storage', 'Enfrashare Telecom Towers', 'Thermal and Wind Energy', 'FrieslandCampina Dairy Foods'],
    history: 'Engro commenced operations in 1965 as Exxon Chemical Pakistan. Following an employee-led buyout in 1991, Engro has diversified into energy, polymer plastics, telecommunications, agriculture, and chemical terminals, serving as the crown jewel of Pakistani industry.',
    price: 342.80,
    change: -5.10,
    changePercent: -1.47,
    peRatio: 5.2,
    pbRatio: 1.25,
    roe: 24.5,
    eps: 65.92,
    dividendHistory: [
      { year: 2025, yield: 14.8, payout: 'Rs 46.00 per share' },
      { year: 2024, yield: 13.5, payout: 'Rs 42.00 per share' },
      { year: 2023, yield: 15.1, payout: 'Rs 48.00 per share' }
    ],
    riskScore: 40,
    competitors: ['FFC', 'EPCL', 'HUBC'],
    news: [
      { title: 'Engro posts record-high export profits from polymer plastic lines', source: 'Dawn News', time: '5 hours ago', sentiment: 'positive' },
      { title: 'Engro Energy enters terminal talks for Thar Coal Phase III', source: 'Express Tribune', time: '1 week ago', sentiment: 'neutral' }
    ],
    website: 'https://www.engro.com'
  },
  {
    symbol: 'SYS',
    name: 'Systems Limited',
    logo: '💻',
    ceo: 'Asif Peer',
    sector: 'Technology & IT Services',
    products: ['Enterprise Software Systems', 'Cloud Solutions', 'E-commerce Platforms', 'Digital Retail Transformation', 'AI & Business Intelligence'],
    history: 'Founded in 1977, Systems Limited was Pakistan\'s first software house. It has evolved into a global IT consulting powerhouse with operations in USA, Europe, Middle East, and APAC, winning back-to-back Forbes Asia\'s Best Under A Billion awards.',
    price: 495.20,
    change: 12.80,
    changePercent: 2.65,
    peRatio: 14.2,
    pbRatio: 4.10,
    roe: 35.4,
    eps: 34.87,
    dividendHistory: [
      { year: 2025, yield: 2.5, payout: 'Rs 8.00 per share + 15% Bonus Shares' },
      { year: 2024, yield: 3.1, payout: 'Rs 6.50 per share' },
      { year: 2023, yield: 2.8, payout: 'Rs 5.00 per share' }
    ],
    riskScore: 55,
    competitors: ['TRG', 'OCTOPUS'],
    news: [
      { title: 'Systems Limited scales European operations with strategic IT acquisition', source: 'MenaFN', time: '4 hours ago', sentiment: 'positive' },
      { title: 'Asif Peer charts AI-First direction for 2026 digital banking frameworks', source: 'Profit Magazine', time: '2 days ago', sentiment: 'positive' }
    ],
    website: 'https://www.systemsltd.com'
  },
  {
    symbol: 'HUBC',
    name: 'The Hub Power Company',
    logo: '🔋',
    ceo: 'Kamran Kamal',
    sector: 'Power Generation & Utilities',
    products: ['Base load thermal energy', 'Thar Mine-mouth Coal Power', 'Chashma and Wind Renewable Operations', 'Exploration & Mining'],
    history: 'HUBC is Pakistan\'s largest independent power producer (IPP). Incorporated in 1991, it pioneered private-sector power investment in the country and accounts for a significant portion of the country\'s total electricity capacity.',
    price: 112.40,
    change: 1.85,
    changePercent: 1.67,
    peRatio: 3.1,
    pbRatio: 0.95,
    roe: 31.8,
    eps: 36.25,
    dividendHistory: [
      { year: 2025, yield: 18.2, payout: 'Rs 18.50 per share' },
      { year: 2024, yield: 16.5, payout: 'Rs 16.00 per share' },
      { year: 2023, yield: 19.4, payout: 'Rs 20.00 per share' }
    ],
    riskScore: 50,
    competitors: ['ENGRO', 'KE'],
    news: [
      { title: 'HUBC declares hefty quarterly payout of Rs 6.00 per share', source: 'KSE Updates', time: '20 mins ago', sentiment: 'positive' },
      { title: 'Fitch upgrades Hub Power credit rating following debt restructuring', source: 'Fitch Ratings', time: '5 days ago', sentiment: 'positive' }
    ],
    website: 'https://www.hubpower.com'
  },
  {
    symbol: 'LUCK',
    name: 'Lucky Cement Limited',
    logo: '🧱',
    ceo: 'Muhammad Ali Tabba',
    sector: 'Construction & Material',
    products: ['Ordinary Portland Cement', 'Sulphate Resistant Cement', 'Kia Lucky Motor Cars', 'Lucky Electric Power'],
    history: 'Established in 1993, Lucky Cement is one of the premier industrial manufacturers in Pakistan, dominant in cement production, automotive production (via Kia franchise), and foreign joint ventures in clinical and energy fields.',
    price: 785.00,
    change: -14.50,
    changePercent: -1.81,
    peRatio: 5.5,
    pbRatio: 1.10,
    roe: 20.2,
    eps: 142.72,
    dividendHistory: [
      { year: 2025, yield: 3.8, payout: 'Rs 22.00 per share' },
      { year: 2024, yield: 3.5, payout: 'Rs 18.00 per share' },
      { year: 2023, yield: 3.2, payout: 'Rs 15.00 per share' }
    ],
    riskScore: 45,
    competitors: ['DGKC', 'MLCF', 'FCCL'],
    news: [
      { title: 'Lucky Cement reports robust export volume growth to East African ports', source: 'Dawn News', time: '12 hours ago', sentiment: 'positive' },
      { title: 'Rising fuel prices put margin pressure on heavy cement producers', source: 'Business Recorder', time: '3 days ago', sentiment: 'negative' }
    ],
    website: 'https://www.lucky-cement.com'
  },
  {
    symbol: 'HBL',
    name: 'Habib Bank Limited',
    logo: '🟢',
    ceo: 'Muhammad Aurangzeb',
    sector: 'Commercial Banking',
    products: ['HBL Mobile Banking', 'Corporate Syndicates', 'Agriculture Lending (HBL Zarai)', 'Konnect by HBL Over-the-Counter'],
    history: 'Habib Bank was founded in Bombay in 1947 and moved to Karachi at the request of Quaid-e-Azam Muhammad Ali Jinnah. It was the first commercial bank of Pakistan and has grown to become the largest bank in network and asset bases.',
    price: 114.20,
    change: 0.95,
    changePercent: 0.84,
    peRatio: 3.6,
    pbRatio: 0.55,
    roe: 18.9,
    eps: 31.72,
    dividendHistory: [
      { year: 2025, yield: 11.5, payout: 'Rs 10.00 per share' },
      { year: 2024, yield: 9.8, payout: 'Rs 9.25 per share' },
      { year: 2023, yield: 8.5, payout: 'Rs 8.00 per share' }
    ],
    riskScore: 30,
    competitors: ['UBL', 'MCB', 'MEBL'],
    news: [
      { title: 'HBL Konnect surpasses 20 million active mobile wallet users', source: 'SBP Pulse', time: '1 day ago', sentiment: 'positive' },
      { title: 'HBL initiates digital carbon offsetting programs for Pakistani farms', source: 'The News', time: '4 days ago', sentiment: 'positive' }
    ],
    website: 'https://www.hbl.com'
  }
];
export const topGainers = [...psxCompanies].sort((a, b) => b.changePercent - a.changePercent);
export const topLosers = [...psxCompanies].sort((a, b) => a.changePercent - b.changePercent);
