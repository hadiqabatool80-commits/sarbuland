import { Course, Badge } from '../types';

export const academyCourses: Course[] = [
  {
    id: 'cert-finlit',
    title: 'Financial Literacy',
    category: 'Fundamentals',
    duration: '2 hours',
    lessons: 5,
    xpValue: 150,
    badgeId: 'badge-finlit',
    modules: [
      'Understanding Income and Savings',
      'The Power of Compound Interest (Pakistan context)',
      'Budgeting with Raast & Cash wallets',
      'Inflation (Mehangai) and purchasing power preservation',
      'Creating your first emergency fund'
    ]
  },
  {
    id: 'cert-fundamental',
    title: 'Fundamental Analysis',
    category: 'Investing',
    duration: '4 hours',
    lessons: 8,
    xpValue: 250,
    badgeId: 'badge-fundamental',
    modules: [
      'Introduction to the Pakistan Stock Exchange (PSX)',
      'How to read an Annual Financial Statement',
      'Key ratios: Price to Earnings (PE) & Price to Book (PB)',
      'Evaluating Return on Equity (ROE) & Earnings per Share (EPS)',
      'Valuing cashflows and dividend stability'
    ]
  },
  {
    id: 'cert-technical',
    title: 'Technical Analysis',
    category: 'Trading',
    duration: '3 hours',
    lessons: 6,
    xpValue: 200,
    badgeId: 'badge-technical',
    modules: [
      'Candlestick Patterns & Trends',
      'Support and Resistance Levels',
      'Moving Averages & MACD Indicators',
      'Relative Strength Index (RSI) triggers',
      'Risk management using stop losses'
    ]
  },
  {
    id: 'cert-portfoliomgt',
    title: 'Portfolio Management',
    category: 'Wealth Building',
    duration: '3.5 hours',
    lessons: 7,
    xpValue: 220,
    badgeId: 'badge-portfoliomgt',
    modules: [
      'Asset Allocation (Stocks, Mutual Funds, Gold, Real Estate)',
      'Diversification principles versus concentration',
      'Rebalancing strategies across life stages',
      'Tax Planning and dividend withholding tax in Pakistan',
      'Setting long term child education / retirement timelines'
    ]
  },
  {
    id: 'cert-islamic',
    title: 'Islamic Finance',
    category: 'Shariah Investing',
    duration: '2.5 hours',
    lessons: 5,
    xpValue: 180,
    badgeId: 'badge-islamic',
    modules: [
      'Principles of Shariah-compliant investing',
      'Meezan Shariah screening templates for stocks',
      'Riba (usury) vs. Musharakah / Mudarabah partnership structures',
      'Purification of non-compliant dividend percentages',
      'Evaluating Islamic Sukuk bonds and Islamic Mutual Funds'
    ]
  },
  {
    id: 'cert-behavioral',
    title: 'Behavioral Finance',
    category: 'Psychology',
    duration: '2 hours',
    lessons: 4,
    xpValue: 160,
    badgeId: 'badge-behavioral',
    modules: [
      'Loss Aversion & Panic Selling',
      'FOMO (Fear of Missing Out) and chasing hyped small-cap stocks',
      'Confirmation Bias in stock chat forums',
      'How to maintain emotional discipline during PSX market corrections'
    ]
  },
  {
    id: 'cert-riskmgt',
    title: 'Risk Management',
    category: 'Security',
    duration: '3 hours',
    lessons: 6,
    xpValue: 200,
    badgeId: 'badge-riskmgt',
    modules: [
      'Standard Deviation & Volatility indices',
      'Beta values of stocks vs KSE-100 index',
      'Position sizing formulas for risk capital',
      'Hedging strategies using national savings certificates and gold'
    ]
  },
  {
    id: 'cert-mentor',
    title: 'Mentorship Excellence',
    category: 'Leadership',
    duration: '5 hours',
    lessons: 10,
    xpValue: 300,
    badgeId: 'badge-mentor',
    modules: [
      'Creating high-quality finance courses',
      'Techniques for 1-on-1 career & retirement consultation',
      'Building your local investment club brand',
      'Ensuring compliance with Pakistan financial adviser regulations'
    ]
  }
];

export const standardBadges: Badge[] = [
  { id: 'badge-starter', title: 'First Steps', description: 'Experience virtual trading with custom Rs. 100 Starter capital.', icon: '🌱', xpRequired: 0 },
  { id: 'badge-finlit', title: 'Literacy Master', description: 'Complete the Financial Literacy Certificate course.', icon: '📚', xpRequired: 150 },
  { id: 'badge-fundamental', title: 'Value Analyst', description: 'Complete the Fundamental Analysis course.', icon: '🧐', xpRequired: 400 },
  { id: 'badge-technical', title: 'Chart Wizard', description: 'Complete the Technical Analysis course.', icon: '📈', xpRequired: 600 },
  { id: 'badge-portfoliomgt', title: 'Wealth Strategist', description: 'Complete the Portfolio Management course.', icon: '💼', xpRequired: 820 },
  { id: 'badge-islamic', title: 'Halal Investor', description: 'Complete the Shariah Compliance course.', icon: '🕋', xpRequired: 1000 },
  { id: 'badge-behavioral', title: 'Zen Mindset', description: 'Complete the Behavioral Finance course.', icon: '🧘', xpRequired: 1160 },
  { id: 'badge-riskmgt', title: 'Shield Guardian', description: 'Complete the Risk Management course.', icon: '🛡️', xpRequired: 1360 },
  { id: 'badge-mentor', title: 'Grandmaster Coach', description: 'Complete the Mentorship Excellence course.', icon: '👑', xpRequired: 1660 }
];

export interface QuizQuestion {
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export const academyQuizzes: Record<string, QuizQuestion[]> = {
  'cert-finlit': [
    {
      question: 'What is the primary factor that causes money to lose its value over time, requiring you to invest?',
      options: ['Interbank rate fluctuation', 'Mehangai / Inflation', 'Currency devaluation solely', 'Mutual fund fees'],
      correctIndex: 1,
      explanation: 'Mehangai (Inflation) erodes the purchasing power of stationary money, meaning that the same currency can purchase fewer goods/services in the future.'
    },
    {
      question: 'Which tool allows instantaneous digital transactions in Pakistan at zero costs?',
      options: ['International Wire Transfer', 'Cheque Clearance', 'Raast Instant Payment System', 'Custom Pay-order'],
      correctIndex: 2,
      explanation: 'Raast is the State Bank of Pakistan\'s instant feeless peer-to-peer real-time gateway.'
    }
  ],
  'cert-fundamental': [
    {
      question: 'Which of the following ratios evaluates the price relative to the historical equity capital backing each share?',
      options: ['Price to Earnings (PE)', 'Debt to Equity', 'Price to Book (PB)', 'Dividend Yield'],
      correctIndex: 2,
      explanation: 'The Price-to-Book (PB) ratio compares the company\'s market value to its absolute asset book value.'
    }
  ],
  'cert-islamic': [
    {
      question: 'Under Shariah screening guidelines, what is evaluated regarding the interest-bearing debt ratio of a screened stock?',
      options: ['Total interest debt must be exactly zero', 'Total interest-bearing debt must remain below 37% or 33% of assets/payouts', 'Only commercial banking sector stocks are acceptable', 'Interest elements require no screening'],
      correctIndex: 1,
      explanation: 'Shariah guidelines allow for a small, restricted ratio of interest-bearing leverage (normally capped below 33% to 37% depending on the exact criteria, such as KMI-30 rules) which then undergoes proportionate dividend purification.'
    }
  ]
};
