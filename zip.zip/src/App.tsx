import React, { useState } from 'react';
import {
  TrendingUp,
  TrendingDown,
  Award,
  BookOpen,
  DollarSign,
  Users,
  Menu,
  X,
  Smartphone,
  Sparkles,
  Layout,
  Sliders,
  Database,
  MapPin,
  Calendar,
  Layers,
  Star,
  Activity,
  User,
  GraduationCap
} from 'lucide-react';
import SaraHologram from './components/SaraHologram';
import RiskEngine from './components/RiskEngine';
import PsxMarket from './components/PsxMarket';
import UserPersonasHub from './components/UserPersonasHub';
import AcademyGrow from './components/AcademyGrow';
import {
  OnboardingStart,
  BankRaast,
  TradingLeague,
  SocialHub,
  FamilyTwin,
  AdminPanel
} from './components/FintechAncillaries';

export default function App() {
  const [activeTab, setActiveTab] = useState<'home' | 'market' | 'risk-dna' | 'learn' | 'personas' | 'utilities'>('home');
  const [userRole, setUserRole] = useState<string>('Beginner');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Gamified User state variables
  const [xpPoints, setXpPoints] = useState<number>(30);
  const [unlockedStars, setUnlockedStars] = useState<number>(1);
  const [unlockedCertificates, setUnlockedCertificates] = useState<string[]>([]);
  const [unlockedBadges, setUnlockedBadges] = useState<string[]>([]);
  
  // Virtual Investment portfolio tracker
  const [portfolioValue, setPortfolioValue] = useState<number>(150000);
  const [pnlRate, setPnlRate] = useState<number>(4.25);
  const [transactionsCount, setTransactionsCount] = useState<number>(0);

  // Quick transaction handler
  const handleAddTransaction = (amount: number, badgeId?: string) => {
    setPortfolioValue((prev) => prev + amount);
    setTransactionsCount((prev) => prev + 1);
    
    // Auto-earn some bonus XP!
    let bonusXp = 25;
    if (badgeId === 'badge-starter') {
      bonusXp = 100;
      if (!unlockedBadges.includes('badge-starter')) {
        setUnlockedBadges([...unlockedBadges, 'badge-starter']);
      }
    }
    setXpPoints((prev) => {
      const nextXp = prev + bonusXp;
      // Auto level stars on XP gains
      if (nextXp >= 1500) setUnlockedStars(5);
      else if (nextXp >= 1000) setUnlockedStars(4);
      else if (nextXp >= 500) setUnlockedStars(3);
      else if (nextXp >= 200) setUnlockedStars(2);
      return nextXp;
    });
  };

  // Complete certificate quiz handler
  const handleCompleteCourseQuiz = (courseId: string, xpValue: number) => {
    if (!unlockedCertificates.includes(courseId)) {
      setUnlockedCertificates([...unlockedCertificates, courseId]);
      const nextXp = xpPoints + xpValue;
      setXpPoints(nextXp);

      // Auto level stars
      if (nextXp >= 1500) setUnlockedStars(5);
      else if (nextXp >= 1000) setUnlockedStars(4);
      else if (nextXp >= 500) setUnlockedStars(3);
      else if (nextXp >= 200) setUnlockedStars(2);
    }
  };

  return (
    <div className="min-h-screen bg-[#FCFAF7] text-[#0A1E4F] flex flex-col font-sans selection:bg-[#D4A017] selection:text-white">
      
      {/* GLOBAL BANNER INDEX OR MAIN HEADER */}
      <header className="sticky top-0 z-40 bg-[#0A1E4F] text-white border-b border-[#D4A017]/30 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="text-2xl font-black bg-gradient-to-r from-[#D4A017] to-amber-400 bg-clip-text text-transparent tracking-widest font-mono">
              SARBULAND
            </span>
            <span className="text-[9px] bg-white/10 text-white font-bold px-2 py-0.5 rounded-full uppercase tracking-wider font-mono">
              PAK_ECOSYSTEM
            </span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1.5">
            {[
              { id: 'home', label: 'Ecosystem Hero', icon: Layout },
              { id: 'market', label: 'PSX Real-Time', icon: TrendingUp },
              { id: 'risk-dna', label: 'Wealth DNA', icon: Sliders },
              { id: 'learn', label: 'Grow Academy', icon: BookOpen },
              { id: 'personas', label: 'Personas', icon: Users },
              { id: 'utilities', label: 'Raast Gateway', icon: Smartphone }
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    setActiveTab(tab.id as any);
                    setMobileMenuOpen(false);
                  }}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                    activeTab === tab.id
                      ? 'bg-[#D4A017] text-[#0A1E4F] font-bold shadow-lg'
                      : 'text-slate-200 hover:text-white hover:bg-white/10'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  {tab.label}
                </button>
              );
            })}
          </nav>

          {/* User Score overview header */}
          <div className="hidden sm:flex items-center gap-4">
            <div className="text-right">
              <span className="text-[10px] text-slate-300 block font-mono">ACCUMULATED_XP</span>
              <span className="text-xs text-[#D4A017] font-extrabold">{xpPoints} XP</span>
            </div>

            <div className="h-8 w-0.5 bg-white/15" />

            <div className="text-right">
              <span className="text-[10px] text-slate-300 block font-mono">STAR_RANK</span>
              <span className="text-xs text-white font-bold flex items-center justify-end gap-1">
                {unlockedStars} <Star className="h-3 w-3 text-[#D4A017] fill-[#D4A017]" />
              </span>
            </div>
          </div>

          {/* Mobile menu trigger */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 hover:bg-white/10 rounded-xl transition-all"
          >
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>

        {/* Mobile Navigation Dropdown */}
        {mobileMenuOpen && (
          <div className="lg:hidden border-t border-white/10 bg-[#0A1E4F] p-4 space-y-2">
            {[
              { id: 'home', label: 'Ecosystem Hero', icon: Layout },
              { id: 'market', label: 'PSX Real-Time', icon: TrendingUp },
              { id: 'risk-dna', label: 'Wealth DNA', icon: Sliders },
              { id: 'learn', label: 'Grow Academy', icon: BookOpen },
              { id: 'personas', label: 'Personas', icon: Users },
              { id: 'utilities', label: 'Raast Gateway', icon: Smartphone }
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    setActiveTab(tab.id as any);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full text-left px-4 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-2.5 cursor-pointer ${
                    activeTab === tab.id
                      ? 'bg-[#D4A017] text-[#0A1E4F] font-bold'
                      : 'text-gray-200 hover:bg-white/10'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  {tab.label}
                </button>
              );
            })}
          </div>
        )}
      </header>

      {/* CORE FRAME LAYOUT */}
      <main className="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        
        {/* Dynamic header metrics card */}
        <div id="dynamic-metrics-bar" className="grid grid-cols-1 md:grid-cols-4 gap-4 bg-[#0A1E4F] text-white border-2 border-[#D4A017]/40 rounded-2xl p-5 shadow-lg relative overflow-hidden">
          {/* Subtle gold decorative gradient sweep */}
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-[#D4A017]/5 to-transparent pointer-events-none" />
          
          <div className="space-y-1 text-center md:text-left relative z-10">
            <span className="text-[10px] text-gray-300 uppercase font-mono tracking-widest block">Portfolio Sandbox Balance</span>
            <h2 className="text-xl font-black text-[#D4A017]">Rs. {portfolioValue.toLocaleString()}</h2>
            <div className="flex justify-center md:justify-start items-center gap-1.5 text-emerald-400 text-xs font-semibold">
              <TrendingUp className="h-3.5 w-3.5" /> +{pnlRate}% Compound Growth
            </div>
          </div>

          <div className="h-px md:h-12 w-full md:w-px bg-white/15 my-2 md:my-0 relative z-10" />

          <div className="space-y-1 text-center md:text-left relative z-10">
            <span className="text-[10px] text-gray-400 uppercase font-mono tracking-widest block">Accredited certifications</span>
            <h2 className="text-xl font-black text-white">{unlockedCertificates.length} Certified</h2>
            <p className="text-[11px] text-gray-300 font-medium">Join the elite financial pool inside Pakistan.</p>
          </div>

          <div className="h-px md:h-12 w-full md:w-px bg-white/15 my-2 md:my-0 relative z-10" />

          <div className="space-y-1 text-center md:text-left relative z-10">
            <span className="text-[10px] text-gray-400 uppercase font-mono tracking-widest block">Active Persona Type</span>
            <h2 className="text-xl font-bold text-[#D4A017] flex items-center justify-center md:justify-start gap-1.5 capitalize">
              {userRole}
            </h2>
            <p className="text-[11px] text-gray-300 font-medium">Customized sandbox configurations applied.</p>
          </div>
        </div>

        {/* ECOSYSTEM TAB SWAPPINGS SWITCHBOARD */}
        {activeTab === 'home' && (
          <div className="space-y-8">
            {/* HERO MODULE */}
            <div id="hero-banner-card" className="relative overflow-hidden rounded-2xl border-2 border-[#D4A017]/40 bg-[#0A1E4F] text-white p-8 md:p-12 shadow-xl">
              {/* Background ambient gold aura glow animation */}
              <div className="absolute top-0 right-0 h-96 w-96 rounded-full bg-[#D4A017]/10 blur-3xl" />
              
              <div className="relative max-w-2xl space-y-5">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold bg-[#D4A017]/25 text-[#D4A017] uppercase tracking-wider font-mono">
                  <Sparkles className="h-3.5 w-3.5 animate-spin" /> Pakistan's First AI Wealth Ecosystem
                </span>

                <h1 className="text-3xl md:text-5xl font-black text-white tracking-tight leading-none">
                  From Your First Rupee To <span className="bg-gradient-to-r from-[#D4A017] to-amber-500 bg-clip-text text-transparent">Financial Freedom</span>.
                </h1>

                <p className="text-sm md:text-base text-gray-200 leading-relaxed max-w-lg">
                  Learn. Invest. Grow. Mentor. Prosper. Elevate your financial literacy confidence with certified Shariah-compliant micro-learning and premium SARA AI advice.
                </p>

                <div className="flex flex-wrap gap-3 pt-3.5">
                  <button
                    onClick={() => setActiveTab('personas')}
                    className="px-6 py-2.5 bg-gradient-to-r from-[#D4A017] to-amber-500 hover:opacity-95 text-[#0A1E4F] font-black text-xs rounded-xl shadow-lg cursor-pointer transition-all hover:scale-103"
                  >
                    Start Here
                  </button>
                  <button
                    onClick={() => setActiveTab('market')}
                    className="px-5 py-2.5 bg-white/5 hover:bg-white/10 border border-white/10 text-white text-xs font-semibold rounded-xl cursor-pointer transition-all"
                  >
                    Explore PSX Market
                  </button>
                </div>
              </div>

              {/* Floating Upward Stock Arrows */}
              <div className="hidden lg:block absolute bottom-8 right-12 text-6xl opacity-35 animate-bounce [animation-duration:4s]">
                📈
              </div>
            </div>

            {/* Quick Starter Onboarding block */}
            <OnboardingStart
              onAddTransaction={handleAddTransaction}
              unlockedBadges={unlockedBadges}
              xpPoints={xpPoints}
            />

            {/* University League rankings preview */}
            <TradingLeague />
          </div>
        )}

        {activeTab === 'market' && (
          <PsxMarket onAddTransaction={handleAddTransaction} />
        )}

        {activeTab === 'risk-dna' && (
          <RiskEngine />
        )}

        {activeTab === 'learn' && (
          <AcademyGrow
            xpPoints={xpPoints}
            unlockedStars={unlockedStars}
            unlockedCertificates={unlockedCertificates}
            onCompleteCourseQuiz={handleCompleteCourseQuiz}
          />
        )}

        {activeTab === 'personas' && (
          <UserPersonasHub
            currentRole={userRole}
            onChangeRole={setUserRole}
            xpPoints={xpPoints}
            unlockedStars={unlockedStars}
          />
        )}

        {activeTab === 'utilities' && (
          <div className="space-y-8">
            <BankRaast />
            <FamilyTwin />
            <SocialHub />
            <AdminPanel xpPoints={xpPoints} />
          </div>
        )}

      </main>

      {/* SARA ASSISTANT FLOATING HOLOGRAM */}
      <SaraHologram userRole={userRole} />

      {/* ECOSYSTEM FOOTER */}
      <footer className="bg-[#0A1E4F] text-[#E5E5E5] border-t border-[#D4A017]/30 py-8 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="space-y-1 text-center md:text-left">
            <h3 className="text-sm font-bold text-white tracking-widest">SARBULAND</h3>
            <p className="text-[11px] text-gray-300 font-mono">© 2026 Sarbuland Inc. Built for regional financial confidence.</p>
          </div>

          <div className="flex gap-4 text-xs text-gray-300">
            <span className="hover:text-white transition-colors cursor-pointer">Security Protocol</span>
            <span className="hover:text-white transition-colors cursor-pointer">Islamic Purification rules</span>
            <span className="hover:text-[#D4A017] transition-colors cursor-pointer">Sovereign Sukuks API</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
