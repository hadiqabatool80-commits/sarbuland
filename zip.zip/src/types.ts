export type UserRole = 'Student' | 'Women' | 'Professional' | 'Investor' | 'Mentor' | 'Beginner' | 'Admin';

export interface Company {
  symbol: string;
  name: string;
  logo: string;
  ceo: string;
  sector: string;
  products: string[];
  history: string;
  price: number;
  change: number;
  changePercent: number;
  peRatio: number;
  pbRatio: number;
  roe: number;
  eps: number;
  dividendHistory: { year: number; yield: number; payout: string }[];
  riskScore: number; // 1-100
  competitors: string[];
  news: { title: string; source: string; time: string; sentiment: 'positive' | 'neutral' | 'negative' }[];
  website: string;
}

export interface Course {
  id: string;
  title: string;
  category: string;
  duration: string;
  lessons: number;
  xpValue: number;
  badgeId: string;
  modules: string[];
}

export interface Badge {
  id: string;
  title: string;
  description: string;
  icon: string;
  xpRequired: number;
}

export interface UniversityLeague {
  rank: number;
  name: string;
  score: number;
  members: number;
  change: 'up' | 'down' | 'same';
}

export interface RiskProfileResponse {
  recommendedAllocation: {
    stocks: number;
    bonds: number;
    gold: number;
    cash: number;
    reit: number;
  };
  portfolioType: string;
  description: string;
  cagrExpectation: string;
  guideline: string;
}

export interface StockAiAnalysis {
  bullCase: string;
  baseCase: string;
  bearCase: string;
  expectedCagr: number;
  volatility: string;
  riskScore: number;
  probabilityOfBull: number;
  projectionYears: { year: number; conservativeValue: number; baseValue: number; aggressiveValue: number }[];
}
