import React, { useState } from 'react';
import { Award, ShieldCheck, DollarSign, Users, Sparkles, Layout, Database, TrendingUp, CheckCircle, Smartphone, ArrowRight, Share2, Star } from 'lucide-react';

interface AncillaryProps {
  onAddTransaction: (amount: number, badgeId?: string) => void;
  unlockedBadges: string[];
  xpPoints: number;
}

// 1. ONBOARDING START TUTORIAL
export function OnboardingStart({ onAddTransaction, unlockedBadges }: AncillaryProps) {
  const [step, setStep] = useState<number>(1);
  const [invested, setInvested] = useState<boolean>(false);

  const startInvest = () => {
    onAddTransaction(100, 'badge-starter');
    setInvested(true);
    setStep(3);
  };

  return (
    <div id="onboarding-starter-section" className="bg-[#0A1E4F]/40 border border-[#D4A017]/30 rounded-2xl p-6 text-center space-y-4">
      {step === 1 && (
        <div className="space-y-4 py-8">
          <div className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-[#D4A017]/10 border border-[#D4A017]/30 text-2xl animate-pulse">
            🌱
          </div>
          <h3 className="text-base font-bold text-white">Experience Investing with Rs. 100 Starter Capital</h3>
          <p className="text-xs text-gray-300 max-w-md mx-auto">
            We will provision an automatic sandbox micro-capital of Rs. 100 for you to buy your very first blue-chip share. Zero risk. Pure learning!
          </p>
          <button
            onClick={() => setStep(2)}
            className="px-6 py-2 bg-[#D4A017] text-[#0A1E4F] font-bold text-xs rounded-xl hover:scale-103 transition-transform cursor-pointer"
          >
            Claim Rs. 100 Gift & Starter Badge
          </button>
        </div>
      )}

      {step === 2 && (
        <div className="space-y-4 py-8">
          <div className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-indigo-500/15 border border-indigo-500/30 text-2xl">
            🏦
          </div>
          <h3 className="text-base font-bold text-white">Buy Your First Islamic Sukuk Bond</h3>
          <p className="text-xs text-gray-300 max-w-md mx-auto">
            Your Rs. 100 gift balance is credited. Choose to allocate it into the stable Meezan Bank Shariah Sukuk Portfolio today.
          </p>
          <button
            onClick={startInvest}
            className="px-6 py-2 bg-gradient-to-r from-emerald-500 to-teal-600 hover:opacity-95 text-white font-bold text-xs rounded-xl shadow-lg cursor-pointer"
          >
            Confirm Rs. 100 Sandbox Allocation
          </button>
        </div>
      )}

      {step === 3 && (
        <div className="space-y-4 py-8">
          <div className="inline-flex h-16 w-16 items-center justify-center rounded-full bg-emerald-500/20 border border-emerald-500/35 text-3xl">
            🏆
          </div>
          <h3 className="text-base font-bold text-[#D4A017]">Congratulations! You are officially an Investor</h3>
          <p className="text-xs text-gray-200 max-w-sm mx-auto">
            You processed your sandbox transaction. <strong>"First Steps" Badge</strong> and +100 XP points have been registered to your profile!
          </p>
          <div className="inline-block p-3 bg-white/5 border border-white/10 rounded-xl">
            <span className="text-xl">🌱</span>
            <span className="text-xs font-bold text-white block mt-1">First Steps Badge</span>
            <span className="text-[10px] text-gray-400 block font-mono">Unlocks Micro Investment Levels</span>
          </div>
        </div>
      )}
    </div>
  );
}

// 2. BANK INTEGRATIONS SYSTEM
export function BankRaast() {
  const [connectedBank, setConnectedBank] = useState<string | null>(null);
  const [integrationStatus, setIntegrationStatus] = useState<string>('');

  const handleBankLink = (bankName: string) => {
    setIntegrationStatus('Connecting API Tunnel...');
    setTimeout(() => {
      setConnectedBank(bankName);
      setIntegrationStatus(`Successfully linked with ${bankName} Open Banking standards! Sandbox deposits and withdraws bypass FBR tax bottlenecks.`);
    }, 1500);
  };

  const banks = [
    { name: 'Meezan Bank', logo: '🕋', color: 'border-emerald-500/30' },
    { name: 'HBL', logo: '🟢', color: 'border-green-500/30' },
    { name: 'Bank Alfalah', logo: '🔴', color: 'border-red-500/30' },
    { name: 'Easypaisa', logo: '📱', color: 'border-[#D4A017]/30' },
    { name: 'Raast Gateway', logo: '⚡', color: 'border-blue-500/30' }
  ];

  return (
    <div id="bank-link-section" className="bg-[#0A1E4F]/30 border border-white/10 rounded-2xl p-5 space-y-4">
      <div>
        <span className="text-[9px] bg-emerald-500/20 text-emerald-300 px-2.5 py-1 rounded-full font-mono font-bold">
          SECURE OPEN BANKING GATEWAY
        </span>
        <h3 className="text-sm font-bold text-white mt-1.5">Direct Banking API Integrations</h3>
        <p className="text-xs text-gray-300">Synchronize your accounts to facilitate frictionless, instant Raast investments.</p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        {banks.map((b) => (
          <button
            key={b.name}
            onClick={() => handleBankLink(b.name)}
            className={`p-3 text-center border rounded-xl cursor-pointer hover:bg-white/5 transition-all text-gray-200 ${
              connectedBank === b.name ? 'border-[#D4A017] bg-[#D4A017]/10' : b.color
            }`}
          >
            <span className="text-xl block mb-1">{b.logo}</span>
            <span className="text-[11px] font-bold block">{b.name}</span>
          </button>
        ))}
      </div>

      {integrationStatus && (
        <div className="p-3 bg-[#122e70]/40 border border-white/10 rounded-xl flex items-center gap-2.5">
          <Smartphone className="h-4.5 w-4.5 text-[#D4A017] shrink-0 animate-bounce" />
          <p className="text-xs text-white leading-snug">{integrationStatus}</p>
        </div>
      )}
    </div>
  );
}

// 3. COLLABORATIVE TRADING LEAGUE
export function TradingLeague() {
  const teams = [
    { uni: 'LUMS Business School', rank: 1, dynamicProfit: '+18.5%', members: 112 },
    { uni: 'IBA Karachi', rank: 2, dynamicProfit: '+16.2%', members: 89 },
    { uni: 'FAST NUCES', rank: 3, dynamicProfit: '+15.8%', members: 165 },
    { uni: 'NUST Islamabad', rank: 4, dynamicProfit: '+14.1%', members: 140 },
    { uni: 'KSBL School of Management', rank: 5, dynamicProfit: '+12.9%', members: 48 }
  ];

  return (
    <div id="collaborative-league-section" className="bg-[#0A1E4F]/30 border border-white/10 rounded-2xl p-5 space-y-4">
      <div className="flex justify-between items-start">
        <div>
          <span className="text-[9px] bg-[#D4A017]/20 text-[#D4A017] px-2.5 py-1 rounded-full font-mono font-bold">
            UNIVERSITY LEAGUE CUP
          </span>
          <h3 className="text-sm font-bold text-white mt-1.5">Collaborative Trading League</h3>
          <p className="text-xs text-gray-300">University vs. University monthly investing championships with real corporate awards.</p>
        </div>
        <span className="text-xs bg-emerald-500/25 text-emerald-400 font-bold px-3 py-1 rounded font-mono">
          Phase 3 Active
        </span>
      </div>

      <div className="space-y-2.5">
        {teams.map((t) => (
          <div key={t.uni} className="p-3 bg-black/20 rounded-xl border border-white/5 flex justify-between items-center">
            <div className="flex items-center gap-3">
              <span className="text-xs font-mono font-bold text-[#D4A017]">#{t.rank}</span>
              <div>
                <h4 className="text-xs text-white font-bold">{t.uni}</h4>
                <p className="text-[9px] text-gray-400">{t.members} Active Members</p>
              </div>
            </div>

            <div className="text-right">
              <span className="text-xs text-emerald-400 font-bold block">{t.dynamicProfit} MTD Return</span>
              <span className="text-[10px] text-[#D4A017]">Qualified for Grand Finals</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// 4. SOCIAL COPY-TRADING & COMMUNITY HUB
export function SocialHub() {
  const [copiedMentor, setCopiedMentor] = useState<string | null>(null);

  const mentors = [
    { name: 'Haris Khan, CFA', return: '+32.4% Annualized', assetFocus: 'Islamic Equities & Software exports', subscribers: 1420 },
    { name: 'Sarah Jaffar', return: '+28.1% Annualized', assetFocus: 'Gold Bullion & REIT portfolios', subscribers: 850 }
  ];

  return (
    <div id="social-copytrading-section" className="grid grid-cols-1 md:grid-cols-12 gap-6">
      <div className="md:col-span-7 bg-white/5 border border-white/10 rounded-2xl p-5 space-y-4">
        <div>
          <h3 className="text-sm font-bold text-white">Social Copy-Trading Vault</h3>
          <p className="text-[11px] text-gray-300 mt-0.5">
            Mirror verified 5-Star investment mentors on our automated Raast execution block.
          </p>
        </div>

        <div className="space-y-3">
          {mentors.map((m) => (
            <div key={m.name} className="p-3.5 bg-black/20 rounded-xl border border-white/5 flex justify-between items-center">
              <div>
                <h4 className="text-xs text-white font-bold flex items-center gap-1.5">
                  {m.name} <span className="text-[9px] bg-emerald-500/20 text-emerald-400 px-1.5 py-0.2 rounded font-mono">5-STAR COACH</span>
                </h4>
                <p className="text-[10px] text-[#D4A017] font-semibold">{m.return}</p>
                <p className="text-[10px] text-gray-300">Focus: {m.assetFocus}</p>
              </div>

              <button
                onClick={() => setCopiedMentor(m.name)}
                className="px-3 py-1.5 bg-[#D1A12A] text-[#0A1E4F] font-bold text-[11px] rounded-lg cursor-pointer hover:bg-opacity-90"
              >
                {copiedMentor === m.name ? 'Mirroring Live' : 'Copy Trade'}
              </button>
            </div>
          ))}
        </div>
      </div>

      <div className="md:col-span-5 bg-white/5 border border-white/10 rounded-2xl p-5 flex flex-col justify-between">
        <h3 className="text-sm font-bold text-white mb-2.5">Global Chat Communities</h3>
        <div className="space-y-3 flex-1">
          {[
            { tag: '#ShariahInvesting', msg: 'Engro Corp purification is verified for 2026.', user: 'Sana_M', time: '11:42 AM' },
            { tag: '#StudentWealthLeague', msg: 'NUST jumps to rank #1 this week! Let\'s go!', user: 'Zaid_N', time: '12:00 PM' }
          ].map((comm, ci) => (
            <div key={ci} className="p-2.5 bg-black/20 rounded-lg border border-white/5 text-left">
              <div className="flex justify-between items-center text-[10px] text-[#D4A017]">
                <span className="font-bold">{comm.tag}</span>
                <span className="text-gray-400">{comm.time}</span>
              </div>
              <p className="text-xs text-white mt-1">{comm.msg}</p>
              <span className="text-[9px] text-gray-400 block mt-0.5">By {comm.user}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// 5. FAMILY ACCOUNT & GLOBAL DIGITAL TWIN
export function FamilyTwin() {
  const [digitalTwinRunning, setDigitalTwinRunning] = useState(false);
  const [projectionResult, setProjectionResult] = useState<string>('');

  const runTwinSimulation = () => {
    setDigitalTwinRunning(true);
    setTimeout(() => {
      setProjectionResult('SARA AI TWIN: Simulated 1,000 future outcomes over 20 years. Recommended modification: Shift 5% Gold portion to export-oriented IT sectors to offset global inflation spikes. Success confidence: 94.2%.');
      setDigitalTwinRunning(false);
    }, 1500);
  };

  return (
    <div id="family-twin-section" className="grid grid-cols-1 md:grid-cols-12 gap-6">
      <div className="md:col-span-6 bg-white/5 border border-white/10 rounded-2xl p-5 space-y-4">
        <div>
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            👨‍👩‍👧‍👦 Family Account Dashboard
          </h3>
          <p className="text-[11px] text-gray-300">
            Link child savings profiles and parents retirement targets inside a single joint portfolio workspace.
          </p>
        </div>

        <div className="space-y-3 bg-black/20 p-4 rounded-xl border border-white/5">
          <div className="flex justify-between items-center">
            <span className="text-xs text-gray-200">Children Education goal (Zaid & Aisha)</span>
            <span className="text-xs text-[#D4A017] font-bold">Rs. 412,000 / Rs. 1,000,000</span>
          </div>
          <div className="h-2 w-full bg-white/10 rounded-full overflow-hidden">
            <div className="h-full bg-blue-500 rounded-full" style={{ width: '41.2%' }} />
          </div>

          <div className="flex justify-between items-center">
            <span className="text-xs text-gray-200">Joint Family House fund</span>
            <span className="text-xs text-emerald-400 font-bold">Rs. 850,000 / Rs. 5,000,000</span>
          </div>
          <div className="h-2 w-full bg-white/10 rounded-full overflow-hidden">
            <div className="h-full bg-emerald-500 rounded-full" style={{ width: '17%' }} />
          </div>
        </div>
      </div>

      <div className="md:col-span-6 bg-white/5 border border-white/10 rounded-2xl p-5 flex flex-col justify-between">
        <div>
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            🤖 AI Digital Twin Simulation
          </h3>
          <p className="text-[11px] text-gray-300">
            Create a live simulation of your spending habits, risk patterns, and multi-year savings to predict future assets.
          </p>
        </div>

        <div className="space-y-3.5 my-3">
          {projectionResult && (
            <div className="p-3 bg-[#D4A017]/10 border border-[#D4A017]/20 rounded-xl text-xs text-white leading-relaxed">
              {projectionResult}
            </div>
          )}
        </div>

        <button
          onClick={runTwinSimulation}
          className="w-full py-2 bg-[#D4A017] text-[#0A1E4F] font-bold text-xs rounded-xl hover:opacity-90 transition-all cursor-pointer"
        >
          {digitalTwinRunning ? '🤖 Syncing habits & simulating...' : 'Launch Habits Assessment Digital Simulation'}
        </button>
      </div>
    </div>
  );
}

// 6. PLATFORM ADMINISTRATION BOARD (ADMIN PANEL)
export function AdminPanel({ xpPoints }: { xpPoints: number }) {
  return (
    <div id="admin-panel-section" className="bg-[#0A1E4F]/30 border border-[#D4A017]/30 rounded-2xl p-5 space-y-4">
      <div>
        <span className="text-[9px] bg-red-500/20 text-red-300 px-2.5 py-1 rounded-full font-mono font-bold">
          ADMIN SECURITY CONTROLS
        </span>
        <h3 className="text-sm font-bold text-white mt-1.5">SARBULAND Ecosystem Platform Statistics</h3>
        <p className="text-xs text-gray-300">Monitor active user ratios, index collections, and system revenue statistics inside Pakistan.</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Active DAU / MAU', value: '14,200 / 185,000', detail: '8.4% Retention growth' },
          { label: 'Assets Under Management', value: 'PKR 850 Million', detail: 'MEBL Mutual Funds linked' },
          { label: 'Platform Commission Revenue', value: 'PKR 14.5 Million', detail: 'Subscription commission: 2.5%' },
          { label: 'Scholarship Success Ratio', value: '85 eligible students accredited', detail: 'LUMS & Fast dominated' }
        ].map((stat, idx) => (
          <div key={idx} className="p-3.5 bg-black/20 rounded-xl border border-white/5 space-y-1 text-center sm:text-left">
            <p className="text-[9px] text-gray-400 uppercase font-mono font-semibold">{stat.label}</p>
            <p className="text-xs text-white font-black">{stat.value}</p>
            <p className="text-[9px] text-[#D4A017]">{stat.detail}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
