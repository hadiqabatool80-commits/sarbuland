import React, { useState, useRef, useEffect } from 'react';
import { Sparkles, MessageSquare, X, Send, Volume2, VolumeX, Mic, Compass } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface Message {
  sender: 'user' | 'sara';
  text: string;
}

interface SaraHologramProps {
  userRole: string;
}

export default function SaraHologram({ userRole }: SaraHologramProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { sender: 'sara', text: `Assalam-o-Alaikum! I am SARA, your AI Wealth Jarvis. Assisting you as a ${userRole}. How can I help you prosper today?` }
  ]);
  const [inputMsg, setInputMsg] = useState('');
  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const handleSendMessage = async (textToSend?: string) => {
    const rawText = textToSend || inputMsg;
    if (!rawText.trim()) return;

    if (!textToSend) setInputMsg('');
    const updatedMessages = [...messages, { sender: 'user', text: rawText }];
    setMessages(updatedMessages);
    setIsTyping(true);

    try {
      const res = await fetch('/api/sara-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: updatedMessages,
          userRole,
          voiceEnabled
        })
      });
      const data = await res.json();
      setMessages([...updatedMessages, { sender: 'sara', text: data.response || "Server responded with an issue. I'm here to assist." }]);
    } catch (e) {
      setMessages([...updatedMessages, { sender: 'sara', text: "Aisay lagta hai internet connection thora slow hai. Let me assist you locally! Always keep a diversified portfolio." }]);
    } finally {
      setIsTyping(false);
    }
  };

  const startListening = () => {
    setIsListening(true);
    // Simulate speaking after 3 seconds
    setTimeout(() => {
      setIsListening(false);
      const spokenPrompts = [
        "Explain Shariah Compliant investing to me",
        "Should I invest Rs 100 in Meezan Bank?",
        "Define PE Ratio simply in Urdu",
        "How is retirement tax handled by FBR?"
      ];
      const randomPrompt = spokenPrompts[Math.floor(Math.random() * spokenPrompts.length)];
      handleSendMessage(randomPrompt);
    }, 2500);
  };

  const quickPrompts = [
    { text: 'Explain PSX Stocks 🇵🇰', query: 'Can you explain the Pakistan Stock Exchange in basic terms?' },
    { text: 'What is Compound Interest? 📈', query: 'Explain the power of compound interest using local parables.' },
    { text: 'Is standard dividend Halal? 🕋', query: 'Explain Meezan stock screening and dividend purification.' },
    { text: 'Tax on dividends? 📑', query: 'What is withholding tax for filers vs non-filers according to FBR?' }
  ];

  return (
    <>
      {/* Tiny floating hologram bubble */}
      <div id="hologram-toggle" className="fixed bottom-6 right-6 z-50">
        {!isOpen && (
          <button
            onClick={() => setIsOpen(true)}
            id="btn-hologram-open"
            className="group relative flex h-16 w-16 items-center justify-center rounded-full bg-[#0A1E4F] text-[#D4A017] shadow-xl ring-2 ring-[#D4A017]/50 transition-all hover:scale-110"
          >
            {/* Holographic glowing pulse effect */}
            <span className="absolute inset-0 rounded-full bg-[#D4A017]/20 animate-ping" />
            <div className="absolute inset-0.5 rounded-full bg-[#0A1E4F] border border-[#D4A017]/30 flex items-center justify-center">
              <Sparkles className="h-7 w-7 text-[#D4A017] group-hover:rotate-12 transition-transform duration-300" />
            </div>
            
            {/* SARA Label */}
            <span className="absolute -top-8 left-1/2 -translate-x-1/2 bg-[#0A1E4F] text-white text-[10px] font-mono px-2 py-0.5 rounded border border-[#D4A017] shadow opacity-0 group-hover:opacity-100 transition-opacity">
              SARA_AI
            </span>
          </button>
        )}
      </div>

      {/* Hologram Expanded Panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            id="sara-assistant-panel"
            initial={{ opacity: 0, scale: 0.9, y: 50 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 50 }}
            className="fixed bottom-6 right-6 z-50 w-full max-w-md overflow-hidden rounded-2xl border border-white/20 bg-[#0A1E4F]/95 shadow-2xl backdrop-blur-xl"
          >
            {/* Hologram Header */}
            <div className="relative border-b border-white/10 bg-gradient-to-r from-[#0a1e4f] to-[#122e70] px-5 py-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <div className="h-10 w-10 rounded-full border border-[#D4A017] bg-[#122e70] flex items-center justify-center">
                    <Sparkles className="h-5 w-5 text-[#D4A017] animate-pulse" />
                  </div>
                  <span className="absolute bottom-0 right-0 h-3 w-3 rounded-full bg-green-500 border-2 border-[#0A1E4F]" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-white tracking-tight flex items-center gap-1.5">
                    SARA AI <span className="text-[10px] bg-[#D4A017]/20 text-[#D4A017] px-1.5 py-0.2 rounded font-mono font-medium">JARVIS_V5</span>
                  </h3>
                  <p className="text-[11px] text-gray-300 font-medium">Bilingual Financial Advisor</p>
                </div>
              </div>

              <div className="flex items-center gap-1">
                <button
                  onClick={() => setVoiceEnabled(!voiceEnabled)}
                  id="btn-toggle-voice"
                  title={voiceEnabled ? "Mute Voice" : "Enable Voice Engine (Roman Urdu/Eng)"}
                  className={`p-2 rounded-lg transition-colors ${voiceEnabled ? 'bg-[#D4A017]/20 text-[#D4A017]' : 'text-gray-400 hover:text-white'}`}
                >
                  {voiceEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
                </button>
                <button
                  onClick={() => setIsOpen(false)}
                  id="btn-hologram-close"
                  className="p-2 text-gray-400 hover:text-white rounded-lg transition-colors"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* AI Active Visualizer */}
            <div className="bg-[#122e70]/60 px-5 py-2 border-b border-white/5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-ping" />
                  <span className="text-[10px] text-emerald-400 font-mono">HOLOGRAPHIC_STREAM_ON</span>
                </div>
              </div>
              <div className="text-[10px] text-gray-400 font-mono">
                Persona: <span className="text-[#D4A017]">{userRole}</span>
              </div>
            </div>

            {/* Chat Body */}
            <div className="h-[280px] overflow-y-auto p-4 space-y-3 custom-scrollbar bg-[#0A1E4F]">
              {messages.map((m, idx) => (
                <div key={idx} className={`flex ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div
                    className={`max-w-[85%] rounded-xl px-4 py-2.5 text-xs shadow-md leading-relaxed ${
                      m.sender === 'user'
                        ? 'bg-gradient-to-br from-[#D4A017] to-amber-600 text-[#0A1E4F] font-bold'
                        : 'bg-white/10 text-gray-100 border border-white/10'
                    }`}
                  >
                    {m.text}
                  </div>
                </div>
              ))}

              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-white/10 text-gray-300 border border-white/5 rounded-xl px-4 py-3 text-xs flex items-center gap-2.5">
                    <div className="flex space-x-1">
                      <span className="h-1.5 w-1.5 bg-[#D4A017] rounded-full animate-bounce [animation-delay:-0.3s]" />
                      <span className="h-1.5 w-1.5 bg-[#D4A017] rounded-full animate-bounce [animation-delay:-0.15s]" />
                      <span className="h-1.5 w-1.5 bg-[#D4A017] rounded-full animate-bounce" />
                    </div>
                    <span className="text-[10px] font-mono text-gray-300">SARA is thinking...</span>
                  </div>
                </div>
              )}
              
              {isListening && (
                <div className="flex justify-start">
                  <div className="bg-[#D4A017]/10 text-[#D4A017] border border-[#D4A017]/20 rounded-xl px-4 py-3 text-xs flex items-center gap-3 w-full">
                    <Mic className="h-4 w-4 animate-pulse" />
                    <div className="flex-1">
                      <p className="font-semibold text-[11px]">SARA listening on MIC...</p>
                      <p className="text-[10px] text-gray-300">Speak now in Urdu or English...</p>
                    </div>
                    <div className="flex space-x-0.5 items-end h-3">
                      <div className="w-0.5 bg-[#D4A017] h-full animate-bounce [animation-delay:-0.2s]" />
                      <div className="w-0.5 bg-[#D4A017] h-2 animate-bounce [animation-delay:-0.5s]" />
                      <div className="w-0.5 bg-[#D4A017] h-3 animate-bounce [animation-delay:-0.1s]" />
                    </div>
                  </div>
                </div>
              )}

              <div ref={chatEndRef} />
            </div>

            {/* Quick Prompts Hub */}
            <div className="px-4 py-2 border-t border-white/10 bg-[#0A1E4F] min-h-[48px] overflow-x-auto whitespace-nowrap scrollbar-none flex gap-2">
              {quickPrompts.map((qp, qidx) => (
                <button
                  key={qidx}
                  onClick={() => handleSendMessage(qp.query)}
                  className="px-2.5 py-1 text-[10px] font-medium bg-white/10 hover:bg-white/20 text-[#D4A017] border border-white/10 rounded-full transition-colors cursor-pointer inline-block"
                >
                  {qp.text}
                </button>
              ))}
            </div>

            {/* Chat Input Footer */}
            <div className="p-4 border-t border-white/10 bg-[#0A1E4F]">
              <div className="flex items-center gap-2">
                <button
                  onClick={startListening}
                  id="btn-voice-input"
                  title="Speak via Microphone"
                  className="p-2.5 rounded-xl bg-white/10 text-gray-300 hover:text-white hover:bg-white/15 transition-colors"
                >
                  <Mic className="h-4 w-4" />
                </button>
                <input
                  type="text"
                  value={inputMsg}
                  onChange={(e) => setInputMsg(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                  placeholder="Ask SARA anything... (e.g. Purify dividends)"
                  className="flex-1 bg-white/10 hover:bg-white/15 text-white placeholder-slate-300 text-xs px-4.5 py-2.5 rounded-xl border border-white/10 focus:outline-none focus:border-[#D4A017] focus:ring-1 focus:ring-[#D4A017]"
                />
                <button
                  onClick={() => handleSendMessage()}
                  id="btn-chat-send"
                  className="p-2.5 rounded-xl bg-[#D4A017] hover:bg-[#b58610] text-[#0A1E4F] font-bold transition-all"
                >
                  <Send className="h-4 w-4" />
                </button>
              </div>
              <p className="text-[10px] text-gray-400 text-center mt-2.5 font-mono">
                ✦ Always check Islamic constraints before real trades.
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
