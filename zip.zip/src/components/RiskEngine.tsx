import React, { useState } from 'react';
import { ShieldAlert, BarChart3, HelpCircle, ArrowRight, RotateCcw, AlertCircle, TrendingUp } from 'lucide-react';
import { RiskProfileResponse } from '../types';

export default function RiskEngine() {
  const [age, setAge] = useState<number>(25);
  const [income, setIncome] = useState<string>('150000');
  const [savings, setSavings] = useState<number>(20);
  const [goals, setGoals] = useState<string>('Retirement Planning');
  const [riskAppetite, setRiskAppetite] = useState<string>('balanced');
  const [experience, setExperience] = useState<string>('beginner');
  const [timeHorizon, setTimeHorizon] = useState<number>(5);

  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [result, setResult] = useState<RiskProfileResponse | null>({
    portfolioType: "Balanced Shariah Guarded Portfolio",
    recommendedAllocation: { stocks: 40, bonds: 30, gold: 15, cash: 10, reit: 5 },
    description: "Your settings indicate a careful balance of high dividend Islamic yields along with moderate stock market exposure to cushion against inflation (Mehangai).",
    cagrExpectation: "14.5% expected annual growth",
    guideline: "Set up a monthly Raast auto-saving instruction of Rs. 10,000 directly to MEBL Growth Fund."
  });

  const handleRunAssessment = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/ai-risk-profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ age, income, savings, goals, riskAppetite, experience, timeHorizon })
      });
      const data = await res.json();
      setResult(data);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  const loadPreset = (type: string) => {
    if (type === 'student') {
      setAge(20);
      setIncome('35000');
      setSavings(15);
      setGoals('University Fees & Growth');
      setRiskAppetite('aggressive');
      setExperience('beginner');
      setTimeHorizon(3);
    } else if (type === 'women') {
      setAge(34);
      setIncome('120000');
      setSavings(35);
      setGoals('Family Education & Passive Income');
      setRiskAppetite('balanced');
      setExperience('intermediate');
      setTimeHorizon(7);
    } else if (type === 'professional') {
      setAge(42);
      setIncome('450000');
      setSavings(25);
      setGoals('Retirement Capitalization');
      setRiskAppetite('aggressive');
      setExperience('expert');
      setTimeHorizon(12);
    }
  };

  return (
    <div id="risk-assessment-section" className="bg-white border border-[#E5E5E5] rounded-2xl p-6 shadow-sm">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
          <span className="text-[10px] bg-[#D4A017]/20 text-[#D4A017] px-2.5 py-1 rounded-full font-mono font-medium">
            AI DUAL-STAGE RISK ENGINE
          </span>
          <h2 id="risk-engine-heading" className="text-xl font-bold text-[#0A1E4F] mt-1.5 tracking-tight">
            Discover Your Wealth DNA
          </h2>
          <p className="text-xs text-gray-600">
            Tailor a production-grade multi-asset portfolio powered by real-time SARA AI parameters.
          </p>
        </div>

        {/* Presets Row */}
        <div className="flex gap-2.5 overflow-x-auto whitespace-nowrap py-1">
          <button
            onClick={() => loadPreset('student')}
            className="px-3 py-1 bg-[#0A1E4F]/5 hover:bg-[#0A1E4F]/10 border border-[#0A1E4F]/15 text-xs text-blue-700 rounded-lg cursor-pointer transition-all font-semibold"
          >
            🎓 Student Preset
          </button>
          <button
            onClick={() => loadPreset('women')}
            className="px-3 py-1 bg-[#D4A017]/10 hover:bg-[#D4A017]/20 border border-[#D4A017]/35 text-xs text-[#b3840e] rounded-lg cursor-pointer transition-all font-bold"
          >
            🌸 Women Wealth Club
          </button>
          <button
            onClick={() => loadPreset('professional')}
            className="px-3 py-1 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-xs text-emerald-800 rounded-lg cursor-pointer transition-all font-semibold"
          >
            💼 Pro Retirement
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Form Inputs inside Left Column */}
        <div className="lg:col-span-5 space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs text-gray-700 font-medium flex justify-between">
              <span>Your Age</span>
              <span className="text-[#D4A017] font-bold">{age} Years</span>
            </label>
            <input
              type="range"
              min="16"
              max="70"
              value={age}
              onChange={(e) => setAge(parseInt(e.target.value))}
              className="w-full accent-[#D4A017]"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs text-gray-700 font-medium">Monthly Active Income (PKR)</label>
            <select
              value={income}
              onChange={(e) => setIncome(e.target.value)}
              className="w-full bg-white border border-slate-200 text-[#0A1E4F] rounded-xl py-2 px-3 text-xs focus:outline-none focus:border-[#D4A017]"
            >
              <option value="35000">Under Rs 50,000</option>
              <option value="120000">Rs 50,000 - 150,000</option>
              <option value="300000">Rs 150,000 - 450,000</option>
              <option value="750000">Above Rs 450,000</option>
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs text-gray-700 font-medium flex justify-between">
              <span>Target Savings Rate</span>
              <span className="text-[#D4A017] font-bold">{savings}% / Month</span>
            </label>
            <input
              type="range"
              min="5"
              max="75"
              value={savings}
              onChange={(e) => setSavings(parseInt(e.target.value))}
              className="w-full accent-[#D4A017]"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs text-gray-700 font-medium">Risk Appetite</label>
              <div className="flex flex-col gap-1.5">
                {['conservative', 'balanced', 'aggressive'].map((level) => (
                  <button
                    key={level}
                    type="button"
                    onClick={() => setRiskAppetite(level)}
                    className={`py-1.5 px-3 text-left rounded-lg text-xs capitalize transition-all ${
                      riskAppetite === level
                        ? 'bg-[#D4A017] text-[#0A1E4F] font-bold shadow-sm'
                        : 'bg-[#FCFAF7] text-gray-700 hover:bg-[#0A1E4F]/5 border border-slate-200'
                    }`}
                  >
                    {level}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs text-gray-700 font-medium font-semibold">User Experience</label>
              <div className="flex flex-col gap-1.5">
                {['beginner', 'intermediate', 'expert'].map((lvl) => (
                  <button
                    key={lvl}
                    type="button"
                    onClick={() => setExperience(lvl)}
                    className={`py-1.5 px-3 text-left rounded-lg text-xs capitalize transition-all ${
                      experience === lvl
                        ? 'bg-[#0A1E4F] text-white font-bold shadow-sm'
                        : 'bg-[#FCFAF7] text-gray-700 hover:bg-[#0A1E4F]/5 border border-slate-200'
                    }`}
                  >
                    {lvl}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs text-gray-700 font-medium flex justify-between">
              <span>Time Horizon</span>
              <span className="text-[#D4A017] font-bold">{timeHorizon} Years</span>
            </label>
            <input
              type="range"
              min="1"
              max="20"
              value={timeHorizon}
              onChange={(e) => setTimeHorizon(parseInt(e.target.value))}
              className="w-full accent-[#D4A017]"
            />
          </div>

          <button
            onClick={handleRunAssessment}
            className="w-full bg-gradient-to-r from-[#D4A017] to-amber-500 hover:opacity-90 text-[#0A1E4F] font-bold text-xs py-2.5 px-4 rounded-xl flex items-center justify-center gap-2 transition-all shadow-lg"
          >
            {isLoading ? (
              <span className="animate-spin h-3.5 w-3.5 border-2 border-[#0A1E4F] border-t-transparent rounded-full" />
            ) : (
              <>
                Analyze Risk Profile <ArrowRight className="h-3.5 w-3.5" />
              </>
            )}
          </button>
        </div>

        {/* Report Result Graphic on Right */}
        <div className="lg:col-span-7 flex flex-col justify-between bg-[#0A1E4F] text-white border-2 border-[#D4A017]/30 rounded-2xl p-5 space-y-4 shadow-lg">
          {result && (
            <>
              <div>
                <span className="text-[10px] bg-red-400/20 text-red-200 px-2 py-0.5 rounded font-mono font-medium">
                  RISK ASSESSMENT PROFILE
                </span>
                <h3 className="text-base font-bold text-[#D4A017] mt-1.5">
                  {result.portfolioType}
                </h3>
                <p className="text-xs text-slate-100 mt-2 leading-relaxed">
                  {result.description}
                </p>
              </div>

              {/* Asset Allocation Breakdown Graphic */}
              <div className="space-y-3.5 bg-white/10 p-4 rounded-xl border border-white/10">
                <h4 className="text-xs font-semibold text-white tracking-wider font-mono">RECOMMENDED ASSET MIX %</h4>
                <div className="space-y-2.5">
                  {[
                    { label: 'Blue-chip Stocks (PSX)', value: result.recommendedAllocation.stocks, color: 'bg-indigo-400' },
                    { label: 'Islamic Shariah Bonds (Sukuk)', value: result.recommendedAllocation.bonds, color: 'bg-emerald-400' },
                    { label: 'Physical Gold / Commodities', value: result.recommendedAllocation.gold, color: 'bg-[#D4A017]' },
                    { label: 'Commercial Real Estate REITs', value: result.recommendedAllocation.reit, color: 'bg-purple-400' },
                    { label: 'High-Yield Cash / Emergency', value: result.recommendedAllocation.cash, color: 'bg-sky-300' }
                  ].map((item, idx) => (
                    <div key={idx} className="space-y-1">
                      <div className="flex justify-between text-[11px] font-medium">
                        <span className="text-slate-200">{item.label}</span>
                        <span className="text-white font-bold">{item.value}%</span>
                      </div>
                      <div className="h-2 w-full bg-white/20 rounded-full overflow-hidden">
                        <div className={`h-full ${item.color} rounded-full`} style={{ width: `${item.value}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Performance Indicator */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div className="bg-[#122e70] border border-white/10 rounded-xl p-3 flex items-center gap-3">
                  <TrendingUp className="h-5 w-5 text-[#D4A017]" />
                  <div>
                    <p className="text-[9px] text-slate-300 uppercase font-mono">Expected CAGR</p>
                    <p className="text-xs text-white font-bold">{result.cagrExpectation}</p>
                  </div>
                </div>

                <div className="bg-[#122e70] border border-white/10 rounded-xl p-3 flex items-center gap-3">
                  <HelpCircle className="h-5 w-5 text-emerald-300" />
                  <div>
                    <p className="text-[9px] text-slate-300 uppercase font-mono">Action Tip</p>
                    <p className="text-[11px] text-white font-medium truncate" title={result.guideline}>
                      {result.guideline}
                    </p>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
