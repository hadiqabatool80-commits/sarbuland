import React, { useState } from 'react';
import { Search, TrendingUp, TrendingDown, Landmark, Star, ExternalLink, RefreshCw, Calendar, Sparkles, Sliders } from 'lucide-react';
import { Company, StockAiAnalysis } from '../types';
import { psxCompanies, topGainers, topLosers } from '../data/psxData';

interface PsxMarketProps {
  onAddTransaction: (amount: number, badgeId?: string) => void;
}

export default function PsxMarket({ onAddTransaction }: PsxMarketProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStock, setSelectedStock] = useState<Company | null>(psxCompanies[0]);
  const [activeTab, setActiveTab] = useState<'profile' | 'wealth-chart' | 'ai-pro'>('profile');
  
  // 10-year Wealth Compound Simulator parameters
  const [monthlyDeposit, setMonthlyDeposit] = useState<number>(3000);
  const [compoundRate, setCompoundRate] = useState<number>(15); // standard PSX historical return is ~15%
  const [simulatedValue, setSimulatedValue] = useState<{ y1: number; y3: number; y5: number; y10: number } | null>({
    y1: 41200,
    y3: 154000,
    y5: 312000,
    y10: 955000
  });

  const [aiAnalysis, setAiAnalysis] = useState<StockAiAnalysis | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);

  // Re-calculate the 10-year wealth growth on parameter adjustment
  React.useEffect(() => {
    if (!selectedStock) return;
    const rateDecimal = compoundRate / 100;
    const monthlyAcc = monthlyDeposit;

    const calcFutureValue = (years: number) => {
      const months = years * 12;
      const rateMonthly = rateDecimal / 12;
      let fv = 0;
      for (let m = 1; m <= months; m++) {
        fv = (fv + monthlyAcc) * (1 + rateMonthly);
      }
      return Math.round(fv);
    };

    setSimulatedValue({
      y1: calcFutureValue(1),
      y3: calcFutureValue(3),
      y5: calcFutureValue(5),
      y10: calcFutureValue(10)
    });
  }, [monthlyDeposit, compoundRate, selectedStock]);

  const loadAiStockScenarios = async (comp: Company) => {
    setIsAiLoading(true);
    setAiAnalysis(null);
    try {
      const res = await fetch('/api/ai-stock-analysis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          symbol: comp.symbol,
          name: comp.name,
          price: comp.price,
          sector: comp.sector
        })
      });
      const data = await res.json();
      setAiAnalysis(data);
    } catch (e) {
      console.error(e);
    } finally {
      setIsAiLoading(false);
    }
  };

  const handleStockClick = (comp: Company) => {
    setSelectedStock(comp);
    setAiAnalysis(null);
    setActiveTab('profile');
    // Pre-seed matching rate based on selected sector stability
    if (comp.symbol === 'SYS') setCompoundRate(22); // Tech high growth
    else if (comp.symbol === 'MEBL') setCompoundRate(17); // Islamic banking giant
    else if (comp.symbol === 'HUBC') setCompoundRate(12); // Steady dividend payer
    else setCompoundRate(15);
  };

  const filteredCompanies = psxCompanies.filter(
    (c) =>
      c.symbol.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.sector.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const corporateActions = [
    { type: 'Dividend', symbol: 'MEBL', detail: 'Rs. 7.00/share interm board payout', date: 'June 25, 2026' },
    { type: 'Bonus Share', symbol: 'SYS', detail: '15% Bonus Stock issue declared', date: 'July 11, 2026' },
    { type: 'Dividend', symbol: 'HUBC', detail: 'Rs. 6.00/share final payout announcement', date: 'June 30, 2026' }
  ];

  return (
    <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
      {/* LEFT COLUMN: PSX Tickers list & search (5 cols) */}
      <div className="xl:col-span-5 bg-[#0A1E4F]/30 border border-white/10 rounded-2xl p-5 flex flex-col justify-between space-y-4">
        <div>
          <span className="text-[9px] bg-[#D4A017]/20 text-[#D4A017] px-2.5 py-1 rounded-full font-mono font-bold uppercase tracking-wider">
            PAKISTAN STOCK EXCHANGE INDEX
          </span>
          <h2 className="text-lg font-bold text-white mt-1">Live Market Board</h2>
          <p className="text-xs text-gray-300">Search top tier Shariah & commercial equities on the PSX index.</p>
        </div>

        {/* Search Input Box */}
        <div className="relative">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search symbol, company name or sector..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-white/5 border border-white/10 text-white rounded-xl py-2 pl-9 pr-4 text-xs focus:outline-none focus:border-[#D4A017]"
          />
        </div>

        {/* Dynamic Lists Tab row */}
        <div className="grid grid-cols-3 gap-2 py-0.5">
          <button
            onClick={() => setSearchTerm('')}
            className="py-1 px-1.5 bg-[#122e70]/40 text-center text-xs text-gray-100 hover:text-white border border-white/10 rounded-lg cursor-pointer font-medium"
          >
            All Stocks ({psxCompanies.length})
          </button>
          <button
            onClick={() => setSearchTerm('Islamic')}
            className="py-1 px-1.5 bg-[#122e70]/40 text-center text-xs text-[#D4A017] border border-white/10 rounded-lg cursor-pointer font-medium"
          >
            🌙 Shariah Filters
          </button>
          <button
            onClick={() => setSearchTerm('Meezan')}
            className="py-1 px-1.5 bg-[#122e70]/40 text-center text-xs text-green-300 border border-white/10 rounded-lg cursor-pointer font-medium"
          >
            📊 Bank Securities
          </button>
        </div>

        {/* Scrollable Stock Cards */}
        <div className="h-[210px] overflow-y-auto space-y-2.5 pr-1.5 custom-scrollbar">
          {filteredCompanies.map((c) => {
            const isGain = c.changePercent >= 0;
            const isSelected = selectedStock?.symbol === c.symbol;
            return (
              <div
                key={c.symbol}
                onClick={() => handleStockClick(c)}
                id={`stock-card-${c.symbol}`}
                className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                  isSelected
                    ? 'bg-[#122e70] border-[#D4A017]/80 ring-1 ring-[#D4A017]/30'
                    : 'bg-white/5 hover:bg-white/10 border-white/10'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className="text-xl">{c.logo}</span>
                  <div>
                    <h3 className="text-xs font-bold text-white flex items-center gap-1">
                      {c.symbol}
                      {c.riskScore <= 30 && <span className="text-[8px] bg-green-500/20 text-green-400 px-1 py-0.2 rounded">Low Risk</span>}
                    </h3>
                    <p className="text-[10px] text-gray-300 max-w-[150px] truncate">{c.name}</p>
                  </div>
                </div>

                <div className="text-right">
                  <p className="text-xs font-bold text-white">Rs. {c.price.toFixed(2)}</p>
                  <p
                    className={`text-[10px] font-bold flex items-center justify-end gap-0.5 ${
                      isGain ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {isGain ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                    {isGain ? '+' : ''}
                    {c.changePercent.toFixed(2)}%
                  </p>
                </div>
              </div>
            );
          })}
          {filteredCompanies.length === 0 && (
            <p className="text-xs text-gray-400 text-center py-8">No stocks found matching '{searchTerm}'</p>
          )}
        </div>

        {/* Corporate announcements row */}
        <div className="pt-2 border-t border-white/10">
          <h4 className="text-[10px] text-gray-400 uppercase tracking-widest font-mono font-bold mb-1.5">Dividend calendar</h4>
          <div className="space-y-1.5">
            {corporateActions.map((act, ai) => (
              <div key={ai} className="flex justify-between text-[10px] bg-black/20 p-2 rounded-lg border border-white/5">
                <span className="text-[#D4A017] font-bold">{act.symbol}</span>
                <span className="text-gray-300 font-medium truncate max-w-[150px]">{act.detail}</span>
                <span className="text-gray-400 font-mono">{act.date}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* RIGHT COLUMN: Detail analysis dashboard & wealth calculators (7 cols) */}
      <div className="xl:col-span-7 bg-[#0A1E4F]/40 border border-white/10 rounded-2xl p-5 flex flex-col justify-between min-h-[480px]">
        {selectedStock ? (
          <>
            {/* Header Company outline */}
            <div className="flex flex-col sm:flex-row justify-between items-start gap-4 border-b border-white/10 pb-4">
              <div className="flex items-center gap-3">
                <span className="text-3xl p-2 bg-[#d4a017]/10 rounded-xl border border-[#d4a017]/25">{selectedStock.logo}</span>
                <div>
                  <h3 id="company-name-heading" className="text-base font-bold text-white flex items-center gap-2">
                    {selectedStock.name} <span className="text-xs text-[#D4A017]">({selectedStock.symbol})</span>
                  </h3>
                  <p className="text-xs text-gray-300">
                    CEO: <span className="text-white font-medium">{selectedStock.ceo}</span> | Sector: <span className="text-[#D4A017] font-medium">{selectedStock.sector}</span>
                  </p>
                </div>
              </div>

              {/* Instant Virtual Invest Box */}
              <button
                onClick={() => {
                  onAddTransaction(selectedStock.price);
                }}
                className="px-4 py-2 bg-gradient-to-r from-emerald-500 to-green-600 hover:opacity-95 text-white font-bold text-xs rounded-xl shadow-lg cursor-pointer transition-all flex items-center gap-1.5"
              >
                <span>Rs. {selectedStock.price.toFixed(1)}</span>
                <span className="font-semibold uppercase tracking-wider text-[9px] bg-white/20 px-1.5 py-0.5 rounded">Quick Buy</span>
              </button>
            </div>

            {/* Analysis Tab Switchers */}
            <div className="flex border-b border-white/5 my-4">
              {[
                { id: 'profile', label: 'Company Profile' },
                { id: 'wealth-chart', label: '10-Yr Wealth Simulator' },
                { id: 'ai-pro', label: 'AI Pro Stock Scenario' }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => {
                    setActiveTab(tab.id as any);
                    if (tab.id === 'ai-pro' && !aiAnalysis) {
                      loadAiStockScenarios(selectedStock);
                    }
                  }}
                  className={`py-2 px-4 text-xs font-semibold cursor-pointer transition-all border-b-2 ${
                    activeTab === tab.id
                      ? 'border-[#D4A017] text-[#D4A017]'
                      : 'border-transparent text-gray-400 hover:text-white'
                  }`}
                >
                  {tab.id === 'ai-pro' && <Sparkles className="h-3 w-3 inline mr-1 text-[#D4A017] animate-pulse" />}
                  {tab.label}
                </button>
              ))}
            </div>

            {/* TAB CONTENT 1: COMPANY PROFILE SUMMARY */}
            {activeTab === 'profile' && (
              <div className="space-y-4 flex-1">
                <p className="text-xs text-gray-200 leading-relaxed italic">
                  "{selectedStock.history}"
                </p>

                {/* Key financial metrics grid */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-black/20 p-4 rounded-xl border border-white/5">
                  <div className="text-center p-2">
                    <p className="text-[10px] text-gray-400 font-mono uppercase">P/E Ratio</p>
                    <p className="text-sm text-white font-bold">{selectedStock.peRatio}x</p>
                  </div>
                  <div className="text-center p-2 border-l border-white/5">
                    <p className="text-[10px] text-gray-400 font-mono uppercase">P/B Ratio</p>
                    <p className="text-sm text-white font-bold">{selectedStock.pbRatio}x</p>
                  </div>
                  <div className="text-center p-2 border-l border-white/5">
                    <p className="text-[10px] text-gray-400 font-mono uppercase">ROE %</p>
                    <p className="text-sm text-emerald-400 font-bold">{selectedStock.roe}%</p>
                  </div>
                  <div className="text-center p-2 border-l border-white/5">
                    <p className="text-[10px] text-gray-400 font-mono uppercase">EPS (PKR)</p>
                    <p className="text-sm text-white font-bold">{selectedStock.eps}</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Products */}
                  <div>
                    <h4 className="text-xs font-bold text-white mb-1.5 uppercase font-mono tracking-wide">Key Products</h4>
                    <div className="flex flex-wrap gap-1.5">
                      {selectedStock.products.map((p, pi) => (
                        <span key={pi} className="text-[10px] bg-white/5 text-gray-300 border border-white/10 px-2 py-0.5 rounded">
                          {p}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Competitors */}
                  <div>
                    <h4 className="text-xs font-bold text-white mb-1.5 uppercase font-mono tracking-wide">Primary Competitors</h4>
                    <div className="flex gap-2">
                      {selectedStock.competitors.map((comp) => (
                        <span
                          key={comp}
                          onClick={() => {
                            const compObj = psxCompanies.find((x) => x.symbol === comp);
                            if (compObj) handleStockClick(compObj);
                          }}
                          className="text-[10px] bg-blue-500/10 hover:bg-blue-500/20 text-blue-300 border border-blue-500/20 px-2.5 py-1 rounded cursor-pointer transition-colors"
                        >
                          {comp} 🔗
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* News feed */}
                <div className="pt-2">
                  <h4 className="text-xs font-bold text-white mb-2 uppercase font-mono tracking-wide">Latest News Insights</h4>
                  <div className="space-y-2">
                    {selectedStock.news.map((n, ni) => (
                      <div key={ni} className="p-2.5 bg-white/5 rounded-lg border border-white/5 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-1">
                        <div>
                          <p className="text-xs text-gray-200 font-medium">{n.title}</p>
                          <p className="text-[10px] text-gray-400">{n.source} | {n.time}</p>
                        </div>
                        <span className={`text-[9px] px-1.5 py-0.2 rounded font-semibold capitalize ${
                          n.sentiment === 'positive' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-gray-500/20 text-gray-400'
                        }`}>
                          {n.sentiment}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* TAB CONTENT 2: 10-YEAR WEALTH SIMULATOR */}
            {activeTab === 'wealth-chart' && (
              <div className="space-y-5 flex-1">
                <div>
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                    Compound Wealth Accelerator Map
                  </h4>
                  <p className="text-[11px] text-gray-300 mt-1">
                    Slide monthly investment values to visualize 10 years of compounding returns at a targeted historical rate.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-white/5 p-4 rounded-xl border border-white/5">
                  <div className="space-y-1.5">
                    <label className="text-[11px] text-gray-300 font-medium flex justify-between">
                      <span>Monthly Contribution</span>
                      <span className="text-[#D4A017] font-bold">Rs. {monthlyDeposit.toLocaleString()}</span>
                    </label>
                    <input
                      type="range"
                      min="500"
                      max="25000"
                      step="500"
                      value={monthlyDeposit}
                      onChange={(e) => setMonthlyDeposit(parseInt(e.target.value))}
                      className="w-full accent-[#D4A017]"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[11px] text-gray-300 font-medium flex justify-between">
                      <span>Target Rate of Return</span>
                      <span className="text-[#D4A017] font-bold">{compoundRate}% Annual</span>
                    </label>
                    <input
                      type="range"
                      min="8"
                      max="30"
                      value={compoundRate}
                      onChange={(e) => setCompoundRate(parseInt(e.target.value))}
                      className="w-full accent-[#D4A017]"
                    />
                  </div>
                </div>

                {/* Simulated Graph representation */}
                {simulatedValue && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-4 gap-2 text-center">
                      {[
                        { label: 'Year 1', val: simulatedValue.y1, marker: 'bg-indigo-500' },
                        { label: 'Year 3', val: simulatedValue.y3, marker: 'bg-[#D4A017]' },
                        { label: 'Year 5', val: simulatedValue.y5, marker: 'bg-emerald-500' },
                        { label: 'Year 10', val: simulatedValue.y10, marker: 'bg-sky-400' }
                      ].map((yr) => (
                        <div key={yr.label} className="p-2 bg-black/30 border border-white/5 rounded-xl hover:scale-103 transition-transform">
                          <span className="text-[9px] text-gray-400 uppercase font-mono block">{yr.label}</span>
                          <span className="text-xs text-white font-bold block mt-0.5">Rs. {yr.val.toLocaleString()}</span>
                        </div>
                      ))}
                    </div>

                    {/* Custom HTML Bar chart simulating compound trajectory */}
                    <div className="bg-black/40 border border-white/5 p-4 rounded-xl flex items-end justify-around h-[140px] pt-8">
                      {[
                        { label: 'Y1', height: 'h-1/5', val: simulatedValue.y1, color: 'bg-indigo-500' },
                        { label: 'Y3', height: 'h-2/5', val: simulatedValue.y3, color: 'bg-[#D4A017]' },
                        { label: 'Y5', height: 'h-3/5', val: simulatedValue.y5, color: 'bg-emerald-500' },
                        { label: 'Y10', height: 'h-full', val: simulatedValue.y10, color: 'bg-sky-400' }
                      ].map((b, idx) => (
                        <div key={idx} className="flex flex-col items-center gap-1.5 h-full justify-end group relative w-12">
                          {/* Tooltip on hover */}
                          <div className="absolute -top-7 opacity-0 group-hover:opacity-100 transition-opacity bg-[#0A1E4F] text-[#D4A017] text-[10px] font-mono font-bold px-2 py-0.5 rounded border border-white/10 z-20 whitespace-nowrap">
                            Rs. {b.val.toLocaleString()}
                          </div>
                          <div className={`w-6 ${b.color} rounded-t-md ${b.height} transition-all duration-500`} />
                          <span className="text-[10px] text-gray-400 font-mono">{b.label}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* TAB CONTENT 3: AI PRO STOCK ANALYSIS */}
            {activeTab === 'ai-pro' && (
              <div className="space-y-4 flex-1">
                <div className="flex justify-between items-center bg-white/5 p-3.5 rounded-xl border border-white/5">
                  <div className="flex items-center gap-2">
                    <Sparkles className="h-4 w-4 text-[#D4A017]" />
                    <div>
                      <h4 className="text-xs font-bold text-white font-semibold">Gemini Advanced AI-Stock Assistant</h4>
                      <p className="text-[10px] text-gray-300">Evaluating multishift corporate reports & growth parameters.</p>
                    </div>
                  </div>
                  <button
                    onClick={() => loadAiStockScenarios(selectedStock)}
                    className="p-1.5 hover:bg-white/10 text-gray-400 hover:text-[#D4A017] rounded-lg transition-colors"
                    title="Reload AI Forecasts"
                  >
                    <RefreshCw className={`h-4.5 w-4.5 ${isAiLoading ? 'animate-spin' : ''}`} />
                  </button>
                </div>

                {isAiLoading && (
                  <div className="flex flex-col items-center justify-center py-16 space-y-3">
                    <div className="h-8 w-8 border-4 border-[#D4A017] border-t-transparent rounded-full animate-spin" />
                    <p className="text-xs text-[#D4A017] font-semibold animate-pulse font-mono">SARA_AI: EXTRAPOLATING 10Y SCENARIOS...</p>
                  </div>
                )}

                {aiAnalysis && (
                  <div className="space-y-4">
                    {/* Scenario Boxes */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      <div className="bg-emerald-500/10 border border-emerald-500/20 p-3 rounded-xl">
                        <span className="text-[9px] bg-emerald-500/20 text-emerald-400 font-bold px-1.5 py-0.2 rounded font-mono uppercase">
                          BULL CASE 🚀
                        </span>
                        <p className="text-[11px] text-gray-200 mt-1.5 leading-relaxed font-medium">
                          {aiAnalysis.bullCase}
                        </p>
                      </div>

                      <div className="bg-purple-500/10 border border-purple-500/20 p-3 rounded-xl">
                        <span className="text-[9px] bg-purple-500/20 text-purple-300 font-bold px-1.5 py-0.2 rounded font-mono uppercase">
                          BASE CASE ⚖️
                        </span>
                        <p className="text-[11px] text-gray-200 mt-1.5 leading-relaxed font-medium">
                          {aiAnalysis.baseCase}
                        </p>
                      </div>

                      <div className="bg-rose-500/10 border border-rose-500/20 p-3 rounded-xl">
                        <span className="text-[9px] bg-rose-500/20 text-rose-400 font-bold px-1.5 py-0.2 rounded font-mono uppercase">
                          BEAR CASE 📉
                        </span>
                        <p className="text-[11px] text-gray-200 mt-1.5 leading-relaxed font-medium">
                          {aiAnalysis.bearCase}
                        </p>
                      </div>
                    </div>

                    {/* Metadata indicators */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-white/5 p-4 rounded-xl border border-white/5">
                      <div className="text-center">
                        <p className="text-[10px] text-gray-400 font-mono uppercase">EXP CAGR</p>
                        <p className="text-xs text-[#D4A017] font-bold">{aiAnalysis.expectedCagr}%</p>
                      </div>
                      <div className="text-center border-l border-white/5">
                        <p className="text-[10px] text-gray-400 font-mono uppercase">VOLATILITY</p>
                        <p className="text-xs text-white font-bold">{aiAnalysis.volatility}</p>
                      </div>
                      <div className="text-center border-l border-white/5">
                        <p className="text-[10px] text-gray-400 font-mono uppercase">RISK SCORE</p>
                        <p className="text-xs text-red-400 font-bold">{aiAnalysis.riskScore}/100</p>
                      </div>
                      <div className="text-center border-l border-white/5">
                        <p className="text-[10px] text-gray-400 font-mono uppercase">BULL PROB%</p>
                        <p className="text-xs text-emerald-400 font-bold">{aiAnalysis.probabilityOfBull}%</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </>
        ) : (
          <p className="text-xs text-gray-300 text-center py-20">Select a KSE stock to drill down detailed corporate history and compound trajectories.</p>
        )}
      </div>
    </div>
  );
}
