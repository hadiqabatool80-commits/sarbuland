import React, { useState } from 'react';
import { Award, BookOpen, Star, Sparkles, CheckCircle2, ChevronRight, HelpCircle, GraduationCap } from 'lucide-react';
import { academyCourses, academyQuizzes } from '../data/academyData';
import { Course } from '../types';

interface AcademyGrowProps {
  xpPoints: number;
  unlockedStars: number;
  unlockedCertificates: string[];
  onCompleteCourseQuiz: (courseId: string, xpValue: number) => void;
}

export default function AcademyGrow({ xpPoints, unlockedStars, unlockedCertificates, onCompleteCourseQuiz }: AcademyGrowProps) {
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(academyCourses[0]);
  const [quizInProgress, setQuizInProgress] = useState<boolean>(false);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState<number>(0);
  const [selectedOptionIndex, setSelectedOptionIndex] = useState<number | null>(null);
  const [quizScore, setQuizScore] = useState<number>(0);
  const [quizCompleted, setQuizCompleted] = useState<boolean>(false);

  const startQuiz = (course: Course) => {
    setSelectedCourse(course);
    setQuizInProgress(true);
    setCurrentQuestionIndex(0);
    setSelectedOptionIndex(null);
    setQuizScore(0);
    setQuizCompleted(false);
  };

  const currentQuizzes = selectedCourse ? academyQuizzes[selectedCourse.id] || [] : [];
  const activeQuestion = currentQuizzes[currentQuestionIndex];

  const handleNextQuizQuestion = () => {
    if (selectedOptionIndex === null) return;
    
    if (selectedOptionIndex === activeQuestion.correctIndex) {
      setQuizScore(quizScore + 1);
    }

    if (currentQuestionIndex + 1 < currentQuizzes.length) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setSelectedOptionIndex(null);
    } else {
      setQuizCompleted(true);
    }
  };

  const finishQuiz = () => {
    if (selectedCourse) {
      // Award the full course graduation
      onCompleteCourseQuiz(selectedCourse.id, selectedCourse.xpValue);
    }
    setQuizInProgress(false);
    setQuizCompleted(false);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* LEFT COLUMN: Progress meters & course list (7 cols) */}
      <div className="lg:col-span-7 bg-white border border-[#E5E5E5] rounded-2xl p-5 flex flex-col justify-between space-y-4 shadow-sm">
        {/* Progress & Stars Panel */}
        <div className="bg-[#0A1E4F] text-white rounded-xl p-4 border border-[#D4A017]/30 space-y-3 shadow-md relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent pointer-events-none" />
          
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 relative z-10">
            <div>
              <p className="text-[10px] text-slate-300 font-mono uppercase">STAR INVESTOR RANK</p>
              <div className="flex items-center gap-1 mt-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star
                    key={star}
                    className={`h-5 w-5 ${
                      star <= unlockedStars ? 'text-[#D4A017] fill-[#D4A017]' : 'text-slate-600'
                    }`}
                  />
                ))}
                <span className="text-xs font-bold text-white ml-2">
                  {unlockedStars} Star Investor {unlockedStars === 5 ? '(Mentor Level)' : ''}
                </span>
              </div>
            </div>

            <div className="text-right">
              <p className="text-[10px] text-slate-300 font-mono uppercase">ACADEMY SCORE</p>
              <p className="text-sm text-emerald-400 font-extrabold">{xpPoints} Accumulated XP</p>
            </div>
          </div>

          <p className="text-[11px] text-gray-200 leading-relaxed font-semibold relative z-10">
            {unlockedStars < 5
              ? `🔥 Reach Level 5 Star Investor (1,500 XP required) to unlock "Mentor Mode", publish premium courses, and schedule paid consulting sessions!`
              : `🏆 CONGRATULATIONS! You have materialized 5-Star Investor status. Your consultation scheduling marketplace is fully active.`}
          </p>
        </div>

        {/* List of accredited courses */}
        <div>
          <h3 className="text-sm font-bold text-[#0A1E4F] mb-3 flex items-center gap-2">
            <BookOpen className="h-4.5 w-4.5 text-[#D4A017]" /> Accredited Certifications ({academyCourses.length})
          </h3>

          <div className="h-[260px] overflow-y-auto space-y-2.5 pr-1.5 custom-scrollbar">
            {academyCourses.map((course) => {
              const isGrand = unlockedCertificates.includes(course.id);
              const selected = selectedCourse?.id === course.id;
              return (
                <div
                  key={course.id}
                  onClick={() => {
                    setSelectedCourse(course);
                    setQuizInProgress(false);
                  }}
                  id={`course-item-${course.id}`}
                  className={`p-3.5 border rounded-xl transition-all cursor-pointer flex items-center justify-between ${
                    selected
                      ? 'bg-[#0A1E4F] text-white border-[#D4A017] shadow-lg'
                      : 'bg-[#FCFAF7] hover:bg-[#0A1E4F]/5 border-slate-200 text-[#0A1E4F]'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-2xl p-1 bg-[#0A1E4F]/5 border border-slate-200 rounded-lg">
                      {isGrand ? '🎓' : '📚'}
                    </span>
                    <div>
                      <h4 className={`text-xs font-bold flex items-center gap-1.5 ${selected ? 'text-white' : 'text-[#0A1E4F]'}`}>
                        {course.title}{' '}
                        {isGrand && (
                          <span className="text-[9px] bg-emerald-500/20 text-emerald-400 px-1.5 py-0.2 rounded font-mono">
                            ACCREDITED
                          </span>
                        )}
                      </h4>
                      <p className={`text-[10px] ${selected ? 'text-slate-200' : 'text-slate-500'}`}>
                        {course.category} | {course.duration} | {course.lessons} Modules
                      </p>
                    </div>
                  </div>

                  <div className="text-right">
                    <p className="text-xs text-[#D4A017] font-bold">+{course.xpValue} XP</p>
                    <ChevronRight className={`h-4.5 w-4.5 inline ${selected ? 'text-white' : 'text-gray-400'}`} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* RIGHT COLUMN: Interactive Course Reader & live Quiz Engine (5 cols) */}
      <div className="lg:col-span-5 bg-[#0A1E4F] border-2 border-[#D4A017]/40 rounded-2xl p-5 flex flex-col justify-between min-h-[460px] shadow-lg text-white">
        {selectedCourse ? (
          <>
            {/* If Quiz is NOT in progress, display Modules list and Quick Assessment Trigger */}
            {!quizInProgress ? (
              <div className="space-y-4 flex-1">
                <div>
                  <span className="text-[9px] bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded font-mono">
                    MODULE DETAILS
                  </span>
                  <h3 className="text-base font-bold text-[#D4A017] mt-1">{selectedCourse.title}</h3>
                  <p className="text-xs text-gray-300">Read curriculum details and trigger the certification quiz.</p>
                </div>

                <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                  {selectedCourse.modules.map((mod, mi) => (
                    <div key={mi} className="p-2.5 bg-white/10 rounded-lg border border-white/10 flex items-start gap-2.5">
                      <span className="text-blue-300 text-xs mt-0.5 font-bold">{mi + 1}.</span>
                      <p className="text-xs text-gray-200">{mod}</p>
                    </div>
                  ))}
                </div>

                {/* Trigger assessment button */}
                <button
                  onClick={() => startQuiz(selectedCourse)}
                  className="w-full py-2.5 bg-gradient-to-r from-[#D4A017] to-amber-500 hover:opacity-90 text-[#0A1E4F] font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg"
                >
                  <GraduationCap className="h-4.5 w-4.5" /> Start Certification Quiz ({academyQuizzes[selectedCourse.id]?.length || 0} Questions)
                </button>
              </div>
            ) : (
              /* If Quiz IS in progress */
              <div className="space-y-4 flex-1">
                <div>
                  <span className="text-[10px] bg-red-400/20 text-red-300 px-2.5 py-0.5 rounded font-mono font-bold animate-pulse">
                    ASSESSMENT ACTIVE
                  </span>
                  <h3 className="text-sm font-bold text-white mt-1.5">{selectedCourse.title}</h3>
                </div>

                {!quizCompleted && activeQuestion ? (
                  <div className="space-y-4">
                    <p className="text-xs text-gray-200 font-semibold bg-white/5 p-3 rounded-lg border border-white/5">
                      Q: {activeQuestion.question}
                    </p>

                    <div className="space-y-2">
                      {activeQuestion.options.map((opt, oi) => (
                        <button
                          key={oi}
                          onClick={() => setSelectedOptionIndex(oi)}
                          className={`w-full text-left p-3 rounded-xl border transition-all text-xs cursor-pointer ${
                            selectedOptionIndex === oi
                              ? 'bg-[#122e70] border-[#D4A017] text-white font-semibold'
                              : 'bg-white/10 hover:bg-white/20 border-white/10 text-gray-100'
                          }`}
                        >
                          {String.fromCharCode(65 + oi)}. {opt}
                        </button>
                      ))}
                    </div>

                    <div className="flex gap-2 justify-end">
                      <button
                        onClick={handleNextQuizQuestion}
                        disabled={selectedOptionIndex === null}
                        className="py-2 px-4 bg-[#D4A017] disabled:bg-slate-500 disabled:opacity-40 text-[#0A1E4F] font-bold text-xs rounded-lg cursor-pointer transition-colors"
                      >
                        Confirm Answer
                      </button>
                    </div>
                  </div>
                ) : (
                  /* Quiz finished outcomes */
                  <div className="space-y-5 text-center py-6">
                    <div className="inline-flex h-16 w-16 items-center justify-center rounded-full bg-emerald-500/20 border border-emerald-500/30">
                      <Award className="h-8 w-8 text-emerald-400" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">Quiz Evaluation Completed</h4>
                      <p className="text-xs text-gray-300 mt-1">
                        You processed all testing modules successfully. Level-ups triggered!
                      </p>
                    </div>

                    <div className="bg-white/10 p-3.5 rounded-xl border border-white/10 font-mono">
                      <p className="text-[11px] text-gray-450 text-slate-300">Score Awarded</p>
                      <p className="text-lg text-emerald-400 font-extrabold">+{selectedCourse.xpValue} XP Points</p>
                    </div>

                    <button
                      onClick={finishQuiz}
                      className="w-full py-2 bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl cursor-pointer transition-colors"
                    >
                      Process Accreditation Badge
                    </button>
                  </div>
                )}
              </div>
            )}
          </>
        ) : (
          <p className="text-xs text-gray-300 text-center py-20">Select an accredited certification from the list to start your financial literacy module.</p>
        )}
      </div>
    </div>
  );
}
