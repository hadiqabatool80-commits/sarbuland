import React, { useState } from 'react';
import { Award, BookOpen, GraduationCap, Heart, Briefcase, Users, Calendar, Star, DollarSign, ArrowUpRight, Trophy, Sparkles, Sliders, CheckCircle, Percent } from 'lucide-react';

interface UserPersonasHubProps {
  currentRole: string;
  onChangeRole: (role: string) => void;
  xpPoints: number;
  unlockedStars: number;
}

export default function UserPersonasHub({ currentRole, onChangeRole, xpPoints, unlockedStars }: UserPersonasHubProps) {
  // Scholarship eligibility engine values
  const [university, setUniversity] = useState('LUMS');
  const [cgpa, setCgpa] = useState<number>(3.5);
  const [familyIncome, setFamilyIncome] = useState<number>(80000);
  const [scholarshipResult, setScholarshipResult] = useState<string | null>(null);

  // Women Savings Planner values
  const [partnerContribution, setPartnerContribution] = useState<number>(15000);
  const [recurringMilestone, setRecurringMilestone] = useState<string>('Kids Higher Education');
  
  // Professional Tax planner values
  const [salarySource, setSalarySource] = useState<number>(180000);
  const [calculatedTax, setCalculatedTax] = useState<number | null>(null);

  // Mentor marketplace scheduler values
  const [mentorBookingConfirmed, setMentorBookingConfirmed] = useState(false);
  const [selectedMentorTime, setSelectedMentorTime] = useState('June 15, 11:30 AM');

  const runScholarshipEngine = () => {
    if (cgpa >= 3.4 && familyIncome <= 150000) {
      setScholarshipResult(`🎉 ACCREDITED: Eligible for SARBULAND-Green Scholarship. 100% textbook reimbursement + Rs 25,000 startup capital grant at ${university}!`);
    } else if (cgpa >= 3.0) {
      setScholarshipResult(`👍 Approved for Partial Merit bursary or Rs 10,000 starter credit.`);
    } else {
      setScholarshipResult(`⚠️ Income restrictions or CGPA requirements did not align. Let's build up your Grow tab XP to unlock secondary career pathways!`);
    }
  };

  const calculateFbrTax = () => {
    const annualSalary = salarySource * 12;
    let tax = 0;
    if (annualSalary <= 600000) {
      tax = 0;
    } else if (annualSalary <= 1200000) {
      tax = (annualSalary - 600000) * 0.025;
    } else if (annualSalary <= 2400000) {
      tax = 15000 + (annualSalary - 1200000) * 0.125;
    } else {
      tax = 165000 + (annualSalary - 2400000) * 0.225;
    }
    setCalculatedTax(Math.round(tax / 12));
  };

  const partnerUniversities = ['LUMS', 'KSBL', 'IBA Karachi', 'FAST', 'NUST', 'GIKI', 'Habib University', 'COMSATS'];

  const femaleMentors = [
    { name: 'Ayesha Fatima, CFA', topic: 'Fixed Sukuks & Corporate Shariah Screener', rating: '4.9 ⭐', price: 'Rs. 2,500/hr' },
    { name: 'Dr. Sana Kidwai', topic: 'Family Estate Planning & Mutual Foundations', rating: '5.0 ⭐', price: 'Rs. 4,000/hr' }
  ];

  const mentorsList = [
    { name: 'Zainab Qazi', expertise: 'Islamic Sukuk Specialist', followers: 2400, courses: 4, reviewCount: '112 reviews' },
    { name: 'Kamran Alvi', expertise: 'High Growth PSX Optioning', followers: 8500, courses: 7, reviewCount: '484 reviews' }
  ];

  return (
    <div className="space-y-6">
      {/* Dynamic Persona selector cards */}
      <div className="bg-white border border-[#E5E5E5] rounded-2xl p-5 shadow-sm">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 mb-5">
          <div>
            <span className="text-[10px] bg-[#D4A017]/20 text-[#D4A017] px-2.5 py-1 rounded-full font-mono font-medium">PERSONA LANDING BENCHMARKS</span>
            <h2 className="text-lg font-bold text-[#0A1E4F] mt-1">Explore Customized Environments</h2>
            <p className="text-xs text-gray-600">Switch views to see how SARBULAND molds user-specific investing utilities.</p>
          </div>
          
          <div className="text-xs text-[#0A1E4F] font-mono">
            Active: <span className="text-[#0A1E4F] font-bold">{currentRole}</span>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {[
            { id: 'Student', icon: '🎓', desc: 'Scholarships & Games', color: 'border-blue-500/30' },
            { id: 'Women', icon: '🌸', desc: 'Wealth Clubs & Planner', color: 'border-amber-400/30' },
            { id: 'Professional', icon: '💼', desc: 'Retirement & FBR Tax', color: 'border-green-400/30' },
            { id: 'Beginner', icon: '🌱', desc: 'Badges & Progression', color: 'border-purple-400/30' },
            { id: 'Mentor', icon: '👑', desc: 'Consulting Marketplace', color: 'border-sky-400/30' },
            { id: 'Investor', icon: '📈', desc: 'Blue-Chip Ratios', color: 'border-[#D4A017]/30' }
          ].map((role) => (
            <button
              key={role.id}
              onClick={() => onChangeRole(role.id)}
              className={`p-3 text-center border rounded-xl cursor-pointer transition-all ${
                currentRole === role.id
                  ? 'bg-[#0A1E4F] border-[#D4A017] text-white shadow-lg ring-2 ring-[#D4A017]/30'
                  : 'bg-[#FCFAF7] hover:bg-[#0A1E4F]/5 border-slate-200 text-[#0A1E4F]'
              }`}
            >
              <div className="text-2xl mb-1.5">{role.icon}</div>
              <h3 className="text-xs font-bold leading-tight">{role.id}</h3>
              <p className={`text-[9px] mt-1 leading-tight ${currentRole === role.id ? 'text-[#D4A017]' : 'text-slate-500'}`}>{role.desc}</p>
            </button>
          ))}
        </div>
      </div>

      {/* 1. STUDENT PERSONA PANEL */}
      {currentRole === 'Student' && (
        <div id="student-persona-panel" className="grid grid-cols-1 md:grid-cols-12 gap-6">
          <div className="md:col-span-7 bg-white border border-[#E5E5E5] rounded-2xl p-5 space-y-4 shadow-sm text-[#0A1E4F]">
            <div>
              <h3 className="text-sm font-bold text-[#0A1E4F] flex items-center gap-2">
                <GraduationCap className="h-4 w-4 text-blue-600" /> Scholarship Eligibility Engine
              </h3>
              <p className="text-[11px] text-gray-600">
                Are you enrolled in one of our partner universities? Test your criteria for special educational endowments.
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              <div className="space-y-1">
                <label className="text-[10px] text-slate-500 uppercase font-mono">University</label>
                <select
                  value={university}
                  onChange={(e) => setUniversity(e.target.value)}
                  className="w-full bg-white border border-slate-200 text-xs text-[#0A1E4F] py-1.5 px-2 rounded-lg"
                >
                  {partnerUniversities.map((uni) => (
                    <option key={uni} value={uni}>{uni}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-slate-500 uppercase font-mono flex justify-between">
                  <span>GPA</span>
                  <span className="text-[#D4A017] font-bold">{cgpa}</span>
                </label>
                <input
                  type="number"
                  min="2.0"
                  max="4.0"
                  step="0.1"
                  value={cgpa}
                  onChange={(e) => setCgpa(parseFloat(e.target.value))}
                  className="w-full bg-white border border-slate-200 text-xs text-[#0A1E4F] py-1 px-2 rounded-lg"
                />
              </div>

              <div className="space-y-1 col-span-2 md:col-span-1">
                <label className="text-[10px] text-slate-500 uppercase font-mono">Monthly Income</label>
                <input
                  type="number"
                  value={familyIncome}
                  onChange={(e) => setFamilyIncome(parseInt(e.target.value))}
                  className="w-full bg-white border border-slate-200 text-xs text-[#0A1E4F] py-1 px-2 rounded-lg"
                />
              </div>
            </div>

            <button
              onClick={runScholarshipEngine}
              className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer shadow"
            >
              Verify Eligibility Criteria
            </button>

            {scholarshipResult && (
              <div className="p-3 bg-blue-50 border border-blue-200 text-blue-900 text-xs rounded-xl flex items-start gap-2">
                <Sparkles className="h-4 w-4 text-[#D4A017] shrink-0 mt-0.5 animate-pulse" />
                <p className="font-medium">{scholarshipResult}</p>
              </div>
            )}
          </div>

          <div className="md:col-span-5 bg-white border border-[#E5E5E5] rounded-2xl p-5 flex flex-col justify-between shadow-sm">
            <h3 className="text-sm font-bold text-[#0A1E4F] mb-2.5 flex items-center gap-2">
              <Trophy className="h-4 w-4 text-[#D4A017]" /> Core Universities League Points
            </h3>
            <div className="space-y-3 flex-1">
              {[
                { name: 'NUST Islamabad', points: 41200, rank: 1, color: 'text-yellow-600' },
                { name: 'IBA Karachi', points: 38900, rank: 2, color: 'text-slate-500' },
                { name: 'LUMS Lahore', points: 35400, rank: 3, color: 'text-[#D4A017]' },
                { name: 'FAST NUCES', points: 31050, rank: 4, color: 'text-slate-400' }
              ].map((uni) => (
                <div key={uni.name} className="flex justify-between items-center p-2.5 bg-[#FCFAF7] rounded-xl border border-slate-200">
                  <div className="flex items-center gap-2.5">
                    <span className={`text-xs font-bold ${uni.color}`}>#{uni.rank}</span>
                    <span className="text-xs text-[#0A1E4F] font-bold">{uni.name}</span>
                  </div>
                  <span className="text-xs text-[#D4A017] font-extrabold">{uni.points.toLocaleString()} XP</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 2. WOMEN PERSONA PANEL */}
      {currentRole === 'Women' && (
        <div id="women-persona-panel" className="grid grid-cols-1 md:grid-cols-12 gap-6">
          <div className="md:col-span-6 bg-white border border-[#E5E5E5] rounded-2xl p-5 space-y-4 shadow-sm text-[#0A1E4F]">
            <div>
              <h3 className="text-sm font-bold text-[#D4A017] flex items-center gap-2">
                <Heart className="h-4 w-4 text-[#D4A017]" /> Women Wealth Savings Planner
              </h3>
              <p className="text-[11px] text-gray-600 mt-0.5">
                Calculate joint milestones for household goals or secondary income portfolios.
              </p>
            </div>

            <div className="space-y-3">
              <div className="space-y-1">
                <label className="text-[10px] text-slate-500 uppercase font-mono">Select Goal</label>
                <select
                  value={recurringMilestone}
                  onChange={(e) => setRecurringMilestone(e.target.value)}
                  className="w-full bg-white border border-slate-200 text-xs text-[#0A1E4F] py-1.5 px-2 rounded-lg cursor-pointer"
                >
                  <option value="Kids Higher Education">Kids Higher Education</option>
                  <option value="Home Renovation & Gold Hedge">Home Renovation & Gold Hedge</option>
                  <option value="Passive Income Trust">Passive Income General Trust</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-slate-500 uppercase font-mono flex justify-between">
                  <span>Monthly Contribution Saving limit</span>
                  <span className="text-[#0A1E4F] font-bold">Rs. {partnerContribution.toLocaleString()}</span>
                </label>
                <input
                  type="range"
                  min="2000"
                  max="100000"
                  step="2000"
                  value={partnerContribution}
                  onChange={(e) => setPartnerContribution(parseInt(e.target.value))}
                  className="w-full accent-[#D4A017]"
                />
              </div>

              <div className="p-3 bg-[#FCFAF7] border border-[#D4A017]/30 rounded-xl">
                <p className="text-[10px] text-slate-500 uppercase font-mono">10 Year Simulated Trust Value</p>
                <p className="text-[#0A1E4F] text-lg font-black">
                  Rs. {(partnerContribution * 12 * 10 * 1.6).toLocaleString()}
                </p>
                <p className="text-[9px] text-gray-500 mt-1 leading-snug">
                  *Uses structural average calculation with 14% historic compound yields including Shariah purification factors.
                </p>
              </div>
            </div>
          </div>

          <div className="md:col-span-6 bg-white border border-[#E5E5E5] rounded-2xl p-5 flex flex-col justify-between shadow-sm">
            <div>
              <h3 className="text-sm font-bold text-[#0A1E4F] flex items-center gap-2">
                <Users className="h-4 w-4 text-[#D4A017]" /> Featured Female Mentors
              </h3>
              <p className="text-[11px] text-gray-600">Set direct counseling dates with Pakistan's certified financial stewards.</p>
            </div>

            <div className="space-y-3 my-3">
              {femaleMentors.map((m, idx) => (
                <div key={idx} className="p-3 bg-[#0A1E4F] text-white rounded-xl border-2 border-[#D4A017]/10 flex justify-between items-center">
                  <div>
                    <h4 className="text-xs font-bold text-white">{m.name}</h4>
                    <p className="text-[10px] text-[#D4A017] font-semibold">{m.topic}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs font-black text-white">{m.price}</p>
                    <span className="text-[9px] bg-white/10 px-1 py-0.2 rounded font-mono text-[#D4A017]">{m.rating}</span>
                  </div>
                </div>
              ))}
            </div>

            <button
              onClick={() => setMentorBookingConfirmed(true)}
              className="w-full py-2 bg-[#D4A017] text-[#0A1E4F] font-bold text-xs rounded-xl hover:opacity-90 transition-all cursor-pointer shadow-md"
            >
              {mentorBookingConfirmed ? "✅ Consultation Scheduled" : "Book 1-on-1 Wealth Consultation"}
            </button>
          </div>
        </div>
      )}

      {/* 3. PROFESSIONAL PERSONA PANEL */}
      {currentRole === 'Professional' && (
        <div id="professional-persona-panel" className="grid grid-cols-1 md:grid-cols-12 gap-6">
          <div className="md:col-span-7 bg-white border border-[#E5E5E5] rounded-2xl p-5 space-y-4 shadow-sm text-[#0A1E4F]">
            <div>
              <h3 className="text-sm font-bold text-[#0A1E4F] flex items-center gap-2">
                <Briefcase className="h-4 w-4 text-green-600" /> Income Tax Planning Estimator (FBR)
              </h3>
              <p className="text-[11px] text-gray-600">
                Identify withholding brackets and calculate monthly estimates for active salary filers in Pakistan.
              </p>
            </div>

            <div className="space-y-3">
              <div className="space-y-1">
                <label className="text-[10px] text-slate-500 uppercase font-mono flex justify-between">
                  <span>Gross Monthly Salary</span>
                  <span className="text-[#0A1E4F] font-bold">Rs. {salarySource.toLocaleString()}</span>
                </label>
                <input
                  type="range"
                  min="50000"
                  max="1000000"
                  step="10000"
                  value={salarySource}
                  onChange={(e) => setSalarySource(parseInt(e.target.value))}
                  className="w-full accent-green-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-3.5 pt-1.5">
                <button
                  onClick={calculateFbrTax}
                  className="py-2.5 bg-green-600 hover:bg-green-700 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer shadow"
                >
                  Estimate Monthly Tax
                </button>
                <div className="bg-[#FCFAF7] p-2 text-center rounded-xl border border-slate-200">
                  <p className="text-[9px] text-slate-500 uppercase font-mono">Monthly tax estimate</p>
                  <p className="text-sm text-green-700 font-bold">
                    {calculatedTax !== null ? `Rs. ${calculatedTax.toLocaleString()}` : "Rs. --"}
                  </p>
                </div>
              </div>

              <p className="text-[9px] text-slate-500 leading-snug">
                *Approximations according to the latest Finance Act. In-app investments inside Shariah equity plans reduce tax load thresholds!
              </p>
            </div>
          </div>

          <div className="md:col-span-5 bg-white border border-[#E5E5E5] rounded-2xl p-5 flex flex-col justify-between shadow-sm">
            <h3 className="text-sm font-bold text-[#0A1E4F] mb-2.5">Retirement Asset Matrix</h3>
            <div className="space-y-2.5">
              {[
                { title: 'Voluntary Pension Mutual Funds', pct: 40, amt: 'Rs. 72,000' },
                { title: 'Islamic Real Estate REIT Value', pct: 25, amt: 'Rs. 45,000' },
                { title: 'Gold Bullion hedge', pct: 15, amt: 'Rs. 27,000' },
                { title: 'Sovereign Sukuk Certificates', pct: 20, amt: 'Rs. 36,000' }
              ].map((ret) => (
                <div key={ret.title} className="p-2 bg-[#FCFAF7] rounded-lg border border-slate-200 space-y-1">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-slate-600 font-medium">{ret.title}</span>
                    <span className="text-[#0A1E4F] font-bold">{ret.pct}%</span>
                  </div>
                  <div className="h-1.5 w-full bg-slate-200 rounded-full overflow-hidden">
                    <div className="h-full bg-green-500 rounded-full" style={{ width: `${ret.pct}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 4. BEGINNER PERSONA PANEL */}
      {currentRole === 'Beginner' && (
        <div id="beginner-persona-panel" className="bg-white border border-[#E5E5E5] rounded-2xl p-5 space-y-4 shadow-sm text-[#0A1E4F]">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-sm font-bold text-[#0A1E4F] flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-purple-600" /> Starter Achievement Pipeline
              </h3>
              <p className="text-[11px] text-gray-600">
                Track your initial milestones to level up your investing journey and unlock Star Badges.
              </p>
            </div>
            <span className="text-xs bg-purple-100 text-purple-800 font-bold px-3 py-1 rounded-full font-mono">
              Level 1: Novice
            </span>
          </div>

          {/* Progress bar */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs text-slate-600">
              <span>Overall Academy Completion</span>
              <span className="text-purple-700 font-black">{xpPoints >= 1000 ? '100%' : xpPoints >= 400 ? '50%' : '15%'}</span>
            </div>
            <div className="h-3 w-full bg-slate-150 rounded-full overflow-hidden border border-slate-200">
              <div
                className="h-full bg-gradient-to-r from-purple-600 to-indigo-600 rounded-full transition-all duration-500"
                style={{ width: xpPoints >= 1000 ? '100%' : xpPoints >= 400 ? '50%' : '15%' }}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
            {[
              { title: 'First Investment', desc: 'Activate Rs 100 starting fund capital.', status: 'Completed', icon: '✅' },
              { title: 'First Profit Scenario', desc: 'Secure compound interest of 12% on PSX.', status: 'Completed', icon: '✅' },
              { title: 'Academic License', desc: 'Complete 3 main certificate courses.', status: xpPoints >= 400 ? 'Completed' : 'Pending', icon: xpPoints >= 400 ? '✅' : '🔒' }
            ].map((ach) => (
              <div key={ach.title} className="p-3 bg-[#FCFAF7] rounded-xl border border-slate-200 flex items-start gap-2.5">
                <span className="text-lg">{ach.icon}</span>
                <div>
                  <h4 className="text-xs text-[#0A1E4F] font-bold">{ach.title}</h4>
                  <p className="text-[10px] text-slate-500 mt-0.5 leading-tight">{ach.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 5. MENTOR PERSONA PANEL */}
      {currentRole === 'Mentor' && (
        <div id="mentor-persona-panel" className="grid grid-cols-1 md:grid-cols-12 gap-6">
          <div className="md:col-span-4 bg-white border border-[#E5E5E5] rounded-2xl p-5 flex flex-col justify-between shadow-sm text-[#0A1E4F]">
            <div>
              <span className="text-[9px] bg-[#D4A017]/25 text-[#0A1E4F] font-bold px-2 py-0.5 rounded font-mono uppercase">
                COACH STATS
              </span>
              <h3 className="text-base font-bold text-[#0A1E4F] mt-1.5">Revenue & Subscriber Matrix</h3>
            </div>

            <div className="space-y-3.5 my-4">
              <div className="p-3 bg-[#FCFAF7] rounded-xl border border-slate-200">
                <p className="text-[10px] text-slate-500 uppercase font-mono">Monthly earnings limit</p>
                <p className="text-[#0A1E4F] text-lg font-black">Rs. 85,000</p>
                <p className="text-[9px] text-slate-600 mt-1">From courses & 1-on-1 consulting appointments.</p>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="p-2.5 bg-[#FCFAF7] rounded-lg border border-slate-200 text-center">
                  <p className="text-[9px] text-slate-500 font-mono">Active Students</p>
                  <p className="text-sm text-[#0A1E4F] font-black mr-0.5">412</p>
                </div>
                <div className="p-2.5 bg-[#FCFAF7] rounded-lg border border-slate-200 text-center">
                  <p className="text-[9px] text-slate-500 font-mono">Total Ratings</p>
                  <p className="text-sm text-[#D4A017] font-black">4.9 ⭐</p>
                </div>
              </div>
            </div>

            <span className="text-[10px] text-slate-500 leading-tight">
              *Requires 5-Star investor level to unlock fully customized subscription pipelines.
            </span>
          </div>

          <div className="md:col-span-8 bg-white border border-[#E5E5E5] rounded-2xl p-5 space-y-4 shadow-sm text-[#0A1E4F]">
            <h3 className="text-sm font-bold text-[#0A1E4F]">Manage Your Active Courses</h3>
            <p className="text-xs text-gray-600">Configure appointment timings and launch lessons directly on the SARBULAND academy index.</p>
            
            <div className="space-y-2.5">
              {mentorsList.map((m, idx) => (
                <div key={idx} className="p-3.5 bg-[#0A1E4F] text-white rounded-xl border-2 border-[#D4A017]/15 flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-bold text-white mb-0.5">{m.name}</h4>
                    <p className="text-[10px] text-[#D4A017] font-semibold">{m.expertise}</p>
                    <p className="text-[9px] text-slate-300 mt-0.5">{m.reviewCount}</p>
                  </div>
                  <div className="text-right">
                    <span className="text-xs text-[#D4A017] font-black block">{m.courses} Active Courses</span>
                    <span className="text-[10px] text-slate-300">{m.followers} Followers</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
